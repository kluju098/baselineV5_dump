﻿import os,sys,time,json
import numpy as np
import pandas as pd
ROOT=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
IN_DIR=os.path.join(ROOT,"LGBM","09","out")
OUT_DIR=os.path.join(ROOT,"LGBM","10","out")
PRUNE08=os.path.join(ROOT,"LGBM","08","out")
os.makedirs(OUT_DIR,exist_ok=True)
os.environ["OMP_NUM_THREADS"]="2"
os.environ["OPENBLAS_NUM_THREADS"]="2"
os.environ["MKL_NUM_THREADS"]="2"
os.environ["VECLIB_MAXIMUM_THREADS"]="2"
os.environ["NUMEXPR_NUM_THREADS"]="2"
LOT=0.01
BASELINE_ACTION_OLD=10
TREES=1000
NMIN_TRAIN=30
import lightgbm as lgb
def fmt(v):
 if isinstance(v,(int,np.integer)): return str(int(v))
 if isinstance(v,(float,np.floating)):
  x=float(v)
  if abs(x)>=1000: return f"{x:,.0f}".replace(","," ")
  if abs(x)>=100: return f"{x:.1f}"
  if abs(x)>=10: return f"{x:.2f}"
  return f"{x:.3f}"
 return str(v)
def usd(pnl_atr,atr):
 return pnl_atr.astype(np.float64)*atr.astype(np.float64)*100.0*LOT
def load_action_stats(stream):
 p=os.path.join(PRUNE08,f"action_stats_{stream}.csv")
 if not os.path.exists(p): return None
 df=pd.read_csv(p)
 return df
def augment_actions_for_222_high(z,stream):
 if stream!="222_high": return z,None
 stats=load_action_stats(stream)
 if stats is None: return z,None
 Aold=z["actions_old"].astype(np.int16)
 present=set(int(x) for x in Aold.tolist())
 cand=stats.sort_values("mean_gain_atr_when_best",ascending=False)
 add=[]
 for _,r in cand.iterrows():
  a=int(r["action"])
  if a in present: continue
  if int(r["best_count"])<3: continue
  add.append(a)
  if len(add)>=5: break
 if not add: return z,None
 newA=np.array(sorted(set(present|set(add))),dtype=np.int16)
 acts=z["pnl_atr_actions"].astype(np.float32)
 acts_full=np.load(os.path.join(ROOT,"LGBM","05","out",f"dataset32_full_{stream}.npz"),allow_pickle=True)["pnl_atr_actions"].astype(np.float32)
 idx=newA.astype(np.int64)
 actsA=acts_full[:,idx].astype(np.float32)
 y=np.argmax(actsA,axis=1).astype(np.int16)
 bestK=np.max(actsA,axis=1).astype(np.float32)
 out={"keep":z["keep"],"y":y,"base_atr":z["base_atr"],"bestK_atr":bestK,"best32_atr":z["best32_atr"],"pnl_atr_actions":actsA,"state_feats":z["state_feats"],"ctx_cont":z["ctx_cont"],"ctx_cat":z["ctx_cat"],"actions_old":newA}
 return out,{"added_actions":add,"K_new":int(newA.size),"actions_old_new":newA.tolist()}
def train_stream(stream,z):
 keep=z["keep"].astype(np.uint8)
 y=z["y"].astype(np.int16)
 base=z["base_atr"].astype(np.float32)
 bestK=z["bestK_atr"].astype(np.float32)
 acts=z["pnl_atr_actions"].astype(np.float32)
 state=z["state_feats"].astype(np.float32)
 ctxc=z["ctx_cont"].astype(np.float32)
 ctxk=z["ctx_cat"]
 hour=ctxk[:,0].astype(np.int16)
 dow=ctxk[:,1].astype(np.int16)
 sess=ctxk[:,2].astype(np.int16)
 month=ctxk[:,3].astype(np.int32)
 atr=ctxc[:,3].astype(np.float32)
 n=base.size
 K=acts.shape[1]
 X=np.concatenate([state,ctxc,np.stack([hour.astype(np.float32),dow.astype(np.float32),sess.astype(np.float32)],axis=1)],axis=1).astype(np.float32)
 cat_idx=[X.shape[1]-3,X.shape[1]-2,X.shape[1]-1]
 params={"objective":"multiclass","num_class":int(K),"learning_rate":0.07,"num_leaves":63,"min_data_in_leaf":30,"feature_fraction":0.9,"bagging_fraction":0.9,"bagging_freq":1,"max_bin":255,"num_threads":2,"verbosity":-1,"seed":1337}
 m_sorted=np.unique(month); m_sorted.sort()
 per=int(np.ceil(float(TREES)/float(m_sorted.size))) if m_sorted.size else TREES
 rem=int(TREES)
 booster=None
 pred=np.full(n,0,np.int16)
 rows=[]
 t0=time.perf_counter()
 for m in m_sorted.tolist():
  mm=(month==m)
  pred_idx=np.flatnonzero(mm & (keep==1))
  if booster is not None and pred_idx.size>0:
   p=booster.predict(X[pred_idx],num_iteration=booster.current_iteration())
   pred[pred_idx]=np.argmax(p,axis=1).astype(np.int16)
  model_atr=acts[mm,pred[mm].astype(np.int64)]
  au=atr[mm]
  base_usd=float(np.sum(usd(base[mm],au)))
  oracle_usd=float(np.sum(usd(bestK[mm],au)))
  model_usd=float(np.sum(usd(model_atr,au)))
  rows.append({"month":int(m),"n":int(mm.sum()),"n_pred":int(pred_idx.size),"base_usd":base_usd,"model_usd":model_usd,"oracleK_usd":oracle_usd,"uplift_usd":model_usd-base_usd,"model_oracle_pct":(model_usd/oracle_usd if abs(oracle_usd)>1e-12 else 0.0)})
  tr_idx=np.flatnonzero(mm & (keep==1))
  if rem>0 and tr_idx.size>=NMIN_TRAIN:
   yy=y[tr_idx].astype(np.int32)
   if np.unique(yy).size>=2:
    add=min(per,rem)
    w=(bestK[tr_idx]-base[tr_idx]).astype(np.float32)
    w=np.clip(w,0.0,2.0)
    dtrain=lgb.Dataset(X[tr_idx],label=yy,weight=w,feature_name=[f"f{i}" for i in range(X.shape[1])],categorical_feature=cat_idx,free_raw_data=True)
    booster=lgb.train(params,dtrain,num_boost_round=int(add),init_model=booster,keep_training_booster=True)
    rem-=int(add)
 rep=pd.DataFrame(rows)
 rep.to_csv(os.path.join(OUT_DIR,f"monthly_{stream}.csv"),index=False)
 used=int(TREES-rem)
 base_all=float(np.sum(usd(base,atr)))
 oracle_all=float(np.sum(usd(bestK,atr)))
 model_all=float(np.sum(usd(acts[np.arange(n),pred.astype(np.int64)],atr)))
 t1=time.perf_counter()
 if booster is not None:
  booster.save_model(os.path.join(OUT_DIR,f"model_{stream}.txt"))
 return {"stream":stream,"n":int(n),"K":int(K),"trees_used":used,"train_sec":float(t1-t0),"base_usd":base_all,"model_usd":model_all,"oracleK_usd":oracle_all,"uplift_usd":model_all-base_all,"model_oracle_pct":(model_all/oracle_all if abs(oracle_all)>1e-12 else 0.0)}
def main():
 files=sorted([f for f in os.listdir(IN_DIR) if f.startswith("datasetK_") and f.endswith(".npz")])
 if not files: raise RuntimeError(("NO_DATASETK",IN_DIR))
 print("ROOT",ROOT)
 print("IN_DIR",IN_DIR)
 print("OUT_DIR",OUT_DIR)
 print("THREADS",2,"TREES",TREES,"NMIN_TRAIN",NMIN_TRAIN)
 adj={}
 sums=[]
 for fn in files:
  stream=fn[len("datasetK_"):-4]
  z=np.load(os.path.join(IN_DIR,fn),allow_pickle=True)
  z2,info=augment_actions_for_222_high(z,stream)
  if info is not None:
   adj[stream]=info
   np.savez_compressed(os.path.join(OUT_DIR,f"datasetK_adj_{stream}.npz"),**z2)
   z=z2
  s=train_stream(stream,z)
  sums.append(s)
  print("STREAM",stream,"K",s["K"],"trees",s["trees_used"],"sec",fmt(s["train_sec"]),"BASE",fmt(s["base_usd"]),"MODEL",fmt(s["model_usd"]),"ORACLEK",fmt(s["oracleK_usd"]),"uplift",fmt(s["uplift_usd"]),"pct_oracle",fmt(s["model_oracle_pct"]))
 sumdf=pd.DataFrame(sums).sort_values("uplift_usd",ascending=False)
 sumdf.to_csv(os.path.join(OUT_DIR,"summary_streams.csv"),index=False)
 with open(os.path.join(OUT_DIR,"adjustments.json"),"w",encoding="utf-8") as f: json.dump(adj,f,ensure_ascii=False)
 tot_base=float(sumdf["base_usd"].sum()); tot_model=float(sumdf["model_usd"].sum()); tot_or=float(sumdf["oracleK_usd"].sum())
 print("[10] SUMMARY_STREAMS")
 print(sumdf.to_string(index=False))
 print("[10] TOTAL","BASE",fmt(tot_base),"MODEL",fmt(tot_model),"ORACLEK",fmt(tot_or),"uplift",fmt(tot_model-tot_base),"pct_oracle",fmt((tot_model/tot_or if abs(tot_or)>1e-12 else 0.0)))
 print("[10] FILES summary_streams.csv monthly_*.csv model_*.txt adjustments.json datasetK_adj_222_high.npz(if adjusted)")
if __name__=="__main__":
 main()
