﻿import os,sys,time,json
import numpy as np
import pandas as pd
ROOT=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
IN_DIR=os.path.join(ROOT,"LGBM","09","out")
OUT_DIR=os.path.join(ROOT,"LGBM","14","out")
os.makedirs(OUT_DIR,exist_ok=True)
os.environ["OMP_NUM_THREADS"]="2"
os.environ["OPENBLAS_NUM_THREADS"]="2"
os.environ["MKL_NUM_THREADS"]="2"
os.environ["VECLIB_MAXIMUM_THREADS"]="2"
os.environ["NUMEXPR_NUM_THREADS"]="2"
LOT=0.01
BASELINE_OLD=10
TREES=800
NMIN_TRAIN_SMALL=40
NMIN_TRAIN=80
TAUS=np.array([0.00,0.02,0.05,0.08,0.10,0.12,0.16,0.20,0.30],np.float32)
import lightgbm as lgb
def fmt(v):
 if isinstance(v,(int,np.integer)): return str(int(v))
 if isinstance(v,(float,np.floating)):
  x=float(v)
  if abs(x)>=1000: return f"{x:,.0f}".replace(","," ")
  if abs(x)>=100: return f"{x:.1f}"
  if abs(x)>=10: return f"{x:.2f}"
  return f"{x:.3f}"
 return str(v)
def usd(pnl_atr,atr):
 return pnl_atr.astype(np.float64)*atr.astype(np.float64)*100.0*LOT
def make_X(z):
 state=z["state_feats"].astype(np.float32)
 ctxc=z["ctx_cont"].astype(np.float32)
 ctxk=z["ctx_cat"]
 hour=ctxk[:,0].astype(np.int16)
 dow=ctxk[:,1].astype(np.int16)
 sess=ctxk[:,2].astype(np.int16)
 X=np.concatenate([state,ctxc,np.stack([hour.astype(np.float32),dow.astype(np.float32),sess.astype(np.float32)],axis=1)],axis=1).astype(np.float32)
 return X
def fw_stream(stream,z):
 keep=z["keep"].astype(np.uint8)
 base=z["base_atr"].astype(np.float32)
 bestK=z["bestK_atr"].astype(np.float32)
 acts=z["pnl_atr_actions"].astype(np.float32)
 ctxc=z["ctx_cont"].astype(np.float32)
 ctxk=z["ctx_cat"]
 actions_old=z["actions_old"].astype(np.int16)
 month=ctxk[:,3].astype(np.int32)
 atr=ctxc[:,3].astype(np.float32)
 n=base.size
 K=acts.shape[1]
 w=np.where(actions_old==BASELINE_OLD)[0]
 if w.size==0: raise RuntimeError(("BASELINE_NOT_IN_K",stream,int(BASELINE_OLD)))
 abase=int(w[0])
 X=make_X(z)
 cat_idx=[X.shape[1]-3,X.shape[1]-2,X.shape[1]-1, X.shape[1]]
 params={"objective":"huber","alpha":0.9,"learning_rate":0.05,"num_leaves":63,"min_data_in_leaf":50,"feature_fraction":0.9,"bagging_fraction":0.9,"bagging_freq":1,"max_bin":255,"num_threads":2,"verbosity":-1,"seed":1337}
 m_sorted=np.unique(month); m_sorted.sort()
 nmin=NMIN_TRAIN_SMALL if stream in ("222_high","332_high") else NMIN_TRAIN
 per=int(np.ceil(float(TREES)/max(1,int(m_sorted.size)))) if m_sorted.size else TREES
 rows=[]
 booster=None
 rem=int(TREES)
 for mi,m in enumerate(m_sorted.tolist()):
  mm=(month==m)
  dec_idx=np.flatnonzero(mm & (keep==1))
  base_usd=float(np.sum(usd(base[mm],atr[mm])))
  oracle_usd=float(np.sum(usd(bestK[mm],atr[mm])))
  if booster is None or dec_idx.size==0:
   for tau in TAUS.tolist():
    rows.append({"stream":stream,"month":int(m),"tau":float(tau),"base_usd":base_usd,"model_usd":base_usd,"uplift_usd":0.0,"oracleK_usd":oracle_usd,"pct_oracle":(base_usd/oracle_usd if abs(oracle_usd)>1e-12 else 0.0),"switch_rate":0.0,"trained_until":int(m_sorted[mi-1]) if mi>0 else -1})
  else:
   Xmm=X[dec_idx]
   Q=np.empty((dec_idx.size,K),np.float32)
   for a in range(K):
    a_col=np.full((dec_idx.size,1),float(a),np.float32)
    Xa=np.concatenate([Xmm,a_col],axis=1)
    Q[:,a]=booster.predict(Xa,num_iteration=booster.current_iteration()).astype(np.float32)
   q_base=Q[:,abase]
   best=np.argmax(Q,axis=1).astype(np.int16)
   q_best=Q[np.arange(best.size),best.astype(np.int64)]
   for tau in TAUS.tolist():
    choose=(q_best-q_base)>=float(tau)
    pred=np.full(best.size,abase,np.int16)
    pred[choose]=best[choose]
    model_atr=acts[dec_idx,pred.astype(np.int64)]
    model_usd=float(np.sum(usd(model_atr,atr[dec_idx])))
    rows.append({"stream":stream,"month":int(m),"tau":float(tau),"base_usd":base_usd,"model_usd":model_usd,"uplift_usd":model_usd-base_usd,"oracleK_usd":oracle_usd,"pct_oracle":(model_usd/oracle_usd if abs(oracle_usd)>1e-12 else 0.0),"switch_rate":float(np.mean(pred!=abase)),"trained_until":int(m_sorted[mi-1]) if mi>0 else -1})
  tr_months=m_sorted[:mi+1]
  tr_idx=np.flatnonzero(np.isin(month,tr_months) & (keep==1))
  if rem>0 and tr_idx.size>=nmin:
   Xr=np.repeat(X[tr_idx],K,axis=0)
   a=np.tile(np.arange(K,dtype=np.int16),tr_idx.size).astype(np.float32).reshape(-1,1)
   y=acts[tr_idx].reshape(-1).astype(np.float32)
   base_rep=np.repeat(acts[tr_idx,abase],K).astype(np.float32)
   delta=(y-base_rep).astype(np.float32)
   wgt=np.clip(np.maximum(delta,0.0),0.0,2.0)+0.02
   Xa=np.concatenate([Xr,a],axis=1).astype(np.float32)
   add=min(per,rem)
   dtrain=lgb.Dataset(Xa,label=delta,weight=wgt,categorical_feature=cat_idx,free_raw_data=True)
   booster=lgb.train(params,dtrain,num_boost_round=int(add),init_model=booster,keep_training_booster=True)
   rem-=int(add)
 return pd.DataFrame(rows)
def main():
 files=sorted([f for f in os.listdir(IN_DIR) if f.startswith("datasetK_") and f.endswith(".npz")])
 if not files: raise RuntimeError(("NO_DATASETK",IN_DIR))
 print("ROOT",ROOT)
 print("IN_DIR",IN_DIR)
 print("OUT_DIR",OUT_DIR)
 print("THREADS",2,"TREES",TREES,"TAUS",json.dumps([float(x) for x in TAUS.tolist()]))
 all_rows=[]
 for fn in files:
  stream=fn[len("datasetK_"):-4]
  z=np.load(os.path.join(IN_DIR,fn),allow_pickle=True)
  df=fw_stream(stream,z)
  df.to_csv(os.path.join(OUT_DIR,f"fw_tau_{stream}.csv"),index=False)
  all_rows.append(df)
  best=df.groupby("tau",as_index=False)["uplift_usd"].sum().sort_values("uplift_usd",ascending=False).head(3)
  print("STREAM",stream,"FW_TOP_TAU")
  print(best.to_string(index=False))
 all_df=pd.concat(all_rows,ignore_index=True)
 all_df.to_csv(os.path.join(OUT_DIR,"fw_all.csv"),index=False)
 tot=all_df.groupby("tau",as_index=False).agg(uplift_usd=("uplift_usd","sum"),base_usd=("base_usd","sum"),model_usd=("model_usd","sum"),oracleK_usd=("oracleK_usd","sum"))
 tot["pct_oracle"]=tot["model_usd"]/np.where(np.abs(tot["oracleK_usd"])>1e-12,tot["oracleK_usd"],1.0)
 tot=tot.sort_values("uplift_usd",ascending=False)
 tot.to_csv(os.path.join(OUT_DIR,"fw_total_by_tau.csv"),index=False)
 print("[14] FW_TOTAL_BY_TAU TOP10")
 print(tot.head(10).to_string(index=False))
 print("[14] FILES fw_total_by_tau.csv fw_all.csv fw_tau_<stream>.csv")
if __name__=="__main__":
 main()
