﻿import os,sys,json,time
import numpy as np,pandas as pd
import lightgbm as lgb
STREAMS=["222_high","222_mid","223_mid","332_high","332_mid","333_mid"]
BASELINE_OLD=10
def _read_meta(m):
    try:
        if isinstance(m,np.ndarray) and m.size==1:
            s=m.reshape(-1)[0]
            if isinstance(s,bytes): s=s.decode("utf-8")
            return json.loads(str(s))
        if isinstance(m,(bytes,bytearray)): return json.loads(m.decode("utf-8"))
    except Exception:
        return {}
    return {}
def _renumber_cat_cols(Xc):
    Xc=np.array(Xc,copy=True)
    maps=[]
    for j in range(Xc.shape[1]):
        col=Xc[:,j].astype(np.int64)
        uniq=np.unique(col)
        maps.append(uniq)
        Xc[:,j]=np.searchsorted(uniq,col)
    return Xc.astype(np.int32),maps
def load_npz(path):
    d=np.load(path,allow_pickle=False)
    keys=set(d.files)
    need=["keep","pnl_atr_actions","actions_old","X","X_cat","y_e2","y_bestK"]
    miss=[k for k in need if k not in keys]
    if miss: raise RuntimeError(("NPZ_MISSING_KEYS",os.path.basename(path),miss,sorted(list(keys))))
    keep=d["keep"].astype(np.uint8).reshape(-1)
    X=d["X"].astype(np.float32)
    Xc=d["X_cat"]
    y_e2=d["y_e2"].astype(np.int32).reshape(-1)
    y_bestK=d["y_bestK"].astype(np.int32).reshape(-1)
    pnl=d["pnl_atr_actions"].astype(np.float32)
    actions_old=d["actions_old"].astype(np.int32).reshape(-1)
    meta=_read_meta(d["meta"]) if "meta" in keys else {}
    if keep.size!=X.shape[0] or keep.size!=y_e2.size or keep.size!=pnl.shape[0] or keep.size!=y_bestK.size:
        raise RuntimeError(("NPZ_SHAPE_MISMATCH",os.path.basename(path),{"keep":keep.shape,"X":X.shape,"y_e2":y_e2.shape,"y_bestK":y_bestK.shape,"pnl":pnl.shape}))
    if pnl.shape[1]!=actions_old.size:
        raise RuntimeError(("NPZ_ACTIONS_MISMATCH",os.path.basename(path),{"pnl_cols":int(pnl.shape[1]),"actions_old":int(actions_old.size)}))
    if isinstance(Xc,np.ndarray) and Xc.ndim==1:
        Xc1=Xc.astype(np.int32).reshape(-1)
        if Xc1.size>0 and int(Xc1.max())<int(X.shape[1]) and int(Xc1.min())>=0 and int(np.unique(Xc1).size)==int(Xc1.size):
            cat_idx=Xc1
            X_full=X
            month_raw=None
            mode="IDX"
            return keep,X_full,cat_idx,month_raw,y_e2,y_bestK,pnl,actions_old,meta,sorted(list(keys)),mode
    Xc2=np.array(Xc,copy=False)
    if Xc2.ndim==1: Xc2=Xc2.reshape(-1,1)
    if Xc2.shape[0]!=X.shape[0]:
        raise RuntimeError(("NPZ_XCAT_ROWS_MISMATCH",os.path.basename(path),{"X":X.shape,"X_cat":Xc2.shape}))
    Xc2=Xc2.astype(np.int32)
    month_pos=int(meta.get("month_pos",Xc2.shape[1]-1)) if isinstance(meta,dict) else (Xc2.shape[1]-1)
    if month_pos<0 or month_pos>=Xc2.shape[1]: month_pos=Xc2.shape[1]-1
    month_raw=Xc2[:,month_pos].astype(np.int32)
    Xc2,maps=_renumber_cat_cols(Xc2)
    X_full=np.concatenate([X,Xc2.astype(np.float32)],axis=1)
    cat_idx=np.arange(X.shape[1],X.shape[1]+Xc2.shape[1],dtype=np.int32)
    mode="VALS"
    meta2=dict(meta) if isinstance(meta,dict) else {}
    meta2["month_pos"]=month_pos
    meta2["cat_maps_sizes"]=[int(u.size) for u in maps]
    return keep,X_full,cat_idx,month_raw,y_e2,y_bestK,pnl,actions_old,meta2,sorted(list(keys)),mode
def baseline_new_index(actions_old):
    w=np.where(actions_old==BASELINE_OLD)[0]
    return int(w[0]) if w.size else 0
def online_fw_gate(keep,X_full,cat_idx,month_raw,y_e2,y_bestK,pnl,actions_old,trees_cap,num_threads,min_hist_n,tau,add_per_month):
    bn=baseline_new_index(actions_old)
    if month_raw is None: raise RuntimeError(("MONTH_RAW_NONE","need X_cat as values matrix"))
    use=(keep>0)
    months=np.unique(month_raw[use])
    months=np.sort(months.astype(np.int32))
    params={"objective":"binary","learning_rate":0.05,"num_leaves":63,"min_data_in_leaf":20,"feature_fraction":0.9,"bagging_fraction":0.9,"bagging_freq":1,"lambda_l2":1.0,"verbosity":-1,"num_threads":int(num_threads),"max_bin":255}
    trees_used=0
    booster=None
    rows=[]
    base_sum=0.0
    model_sum=0.0
    switch_n=0
    dec_n=0
    for m in months:
        test_idx=np.where((month_raw==m)&use)[0]
        if test_idx.size==0:
            rows.append([int(m),0,0.0,0.0,0.0,trees_used,0])
            continue
        train_idx=np.where((month_raw<m)&use)[0]
        train_n=int(train_idx.size)
        trained_now=0
        if train_n>=int(min_hist_n) and trees_used<int(trees_cap):
            add=min(int(add_per_month),int(trees_cap-trees_used))
            dtrain=lgb.Dataset(X_full[train_idx],label=y_e2[train_idx],categorical_feature=cat_idx.tolist(),free_raw_data=True)
            if booster is None: booster=lgb.train(params,dtrain,num_boost_round=int(add))
            else: booster=lgb.train(params,dtrain,num_boost_round=int(add),init_model=booster,keep_training_booster=True)
            trees_used+=int(add);trained_now=int(add)
        if booster is None:
            sw=np.zeros(test_idx.size,dtype=np.uint8);pmean=0.0
        else:
            p=booster.predict(X_full[test_idx]).astype(np.float32)
            sw=(p>=float(tau)).astype(np.uint8)
            pmean=float(p.mean())
        chosen=np.where(sw>0,y_bestK[test_idx],bn).astype(np.int32)
        base_m=float(pnl[test_idx,bn].sum())
        model_m=float(pnl[test_idx,chosen].sum())
        uplift_m=float(model_m-base_m)
        sw_rate=float(sw.mean()) if test_idx.size else 0.0
        base_sum+=base_m;model_sum+=model_m;switch_n+=int(sw.sum());dec_n+=int(test_idx.size)
        rows.append([int(m),int(test_idx.size),uplift_m,sw_rate,pmean,trees_used,trained_now])
    uplift=float(model_sum-base_sum)
    avg_sw=float(switch_n/dec_n) if dec_n else 0.0
    return {"base_atr_sum":base_sum,"model_atr_sum":model_sum,"uplift_atr_sum":uplift,"avg_switch_rate":avg_sw,"trees_used":int(trees_used),"months":int(months.size),"baseline_new":int(bn)},pd.DataFrame(rows,columns=["month","n_dec","uplift_atr","switch_rate","p_mean","trees_used","trained_now"])
def main(root):
    IN_DIR=os.environ.get("IN_DIR",os.path.join(root,"LGBM","22","out"))
    OUT_DIR=os.environ.get("OUT_DIR",os.path.join(root,"LGBM","24","out"))
    THREADS=int(os.environ.get("THREADS","2"))
    TREES_LIST=[int(x) for x in os.environ.get("TREES_LIST","1500,3000").split(",")]
    MIN_HIST_LIST=[int(x) for x in os.environ.get("MIN_HIST_LIST","80,120,200").split(",")]
    TAU_LIST=[float(x) for x in os.environ.get("TAU_LIST","0.35,0.45,0.50,0.60").split(",")]
    ADD_PER_MONTH=int(os.environ.get("ADD_PER_MONTH","200"))
    os.makedirs(OUT_DIR,exist_ok=True)
    print("ROOT",root)
    print("IN_DIR",IN_DIR)
    print("OUT_DIR",OUT_DIR)
    print("THREADS",THREADS,"ADD_PER_MONTH",ADD_PER_MONTH,"BASELINE_OLD",BASELINE_OLD)
    print("TREES_LIST",TREES_LIST)
    print("MIN_HIST_LIST",MIN_HIST_LIST)
    print("TAU_LIST",TAU_LIST)
    datasets={}
    print("[24] NPZ_AUDIT_KEYS")
    for s in STREAMS:
        p=os.path.join(IN_DIR,f"datasetE2_{s}.npz")
        keep,X_full,cat_idx,month_raw,y_e2,y_bestK,pnl,actions_old,meta,keys,mode=load_npz(p)
        bn=baseline_new_index(actions_old)
        months=np.unique(month_raw[keep>0]);months=np.sort(months.astype(np.int32))
        print(" STREAM",s,"mode",mode,"n",int(keep.size),"K",int(pnl.shape[1]),"baseline_new",bn,"X_dim",int(X_full.shape[1]),"cat_cols",cat_idx.tolist(),"months",int(months.size),"range",f"{int(months.min()) if months.size else None}-{int(months.max()) if months.size else None}")
        datasets[s]=(keep,X_full,cat_idx,month_raw,y_e2,y_bestK,pnl,actions_old)
    rows=[];t0=time.time()
    for trees_cap in TREES_LIST:
        for min_hist in MIN_HIST_LIST:
            for tau in TAU_LIST:
                tot_base=0.0;tot_model=0.0;tot_upl=0.0;sws=[]
                for s in STREAMS:
                    keep,X_full,cat_idx,month_raw,y_e2,y_bestK,pnl,actions_old=datasets[s]
                    rep,_=online_fw_gate(keep,X_full,cat_idx,month_raw,y_e2,y_bestK,pnl,actions_old,trees_cap=trees_cap,num_threads=THREADS,min_hist_n=min_hist,tau=tau,add_per_month=ADD_PER_MONTH)
                    tot_base+=rep["base_atr_sum"];tot_model+=rep["model_atr_sum"];tot_upl+=rep["uplift_atr_sum"];sws.append(rep["avg_switch_rate"])
                avg_sw=float(np.mean(sws)) if sws else 0.0
                rows.append([trees_cap,min_hist,tau,tot_base,tot_model,tot_upl,avg_sw])
                print("[GRID] trees_cap",trees_cap,"min_hist",min_hist,"tau",tau,"BASE_ATR",f"{tot_base:.6f}","MODEL_ATR",f"{tot_model:.6f}","UPLIFT_ATR",f"{tot_upl:.6f}","avg_sw",f"{avg_sw:.6f}")
    res=pd.DataFrame(rows,columns=["trees_cap","min_hist_n","tau","base_atr_sum","model_atr_sum","uplift_atr_sum","avg_switch_rate"])
    res=res.sort_values(["uplift_atr_sum","avg_switch_rate"],ascending=[False,True]).reset_index(drop=True)
    res.to_csv(os.path.join(OUT_DIR,"grid_results.csv"),index=False)
    print("[24] TOP10")
    print(res.head(10).to_string(index=False))
    best=res.iloc[0].to_dict() if len(res) else {}
    meta={"best":best,"n_rows":int(len(res)),"elapsed_sec":float(time.time()-t0)}
    with open(os.path.join(OUT_DIR,"best_config.json"),"w",encoding="utf-8") as f: json.dump(meta,f,ensure_ascii=False,indent=2)
    print("[24] FILES grid_results.csv best_config.json")
if __name__=="__main__":
    root=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
    main(root)
