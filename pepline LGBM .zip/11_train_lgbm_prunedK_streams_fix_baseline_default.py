﻿import os,sys,time,json
import numpy as np
import pandas as pd
ROOT=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
IN_DIR=os.path.join(ROOT,"LGBM","09","out")
OUT_DIR=os.path.join(ROOT,"LGBM","11","out")
os.makedirs(OUT_DIR,exist_ok=True)
os.environ["OMP_NUM_THREADS"]="2"
os.environ["OPENBLAS_NUM_THREADS"]="2"
os.environ["MKL_NUM_THREADS"]="2"
os.environ["VECLIB_MAXIMUM_THREADS"]="2"
os.environ["NUMEXPR_NUM_THREADS"]="2"
LOT=0.01
BASELINE_ACTION_OLD=10
TREES=1000
NMIN_TRAIN=30
import lightgbm as lgb
def fmt(v):
 if isinstance(v,(int,np.integer)): return str(int(v))
 if isinstance(v,(float,np.floating)):
  x=float(v)
  if abs(x)>=1000: return f"{x:,.0f}".replace(","," ")
  if abs(x)>=100: return f"{x:.1f}"
  if abs(x)>=10: return f"{x:.2f}"
  return f"{x:.3f}"
 return str(v)
def usd(pnl_atr,atr):
 return pnl_atr.astype(np.float64)*atr.astype(np.float64)*100.0*LOT
def train_stream(stream,z):
 keep=z["keep"].astype(np.uint8)
 y=z["y"].astype(np.int16)
 base=z["base_atr"].astype(np.float32)
 bestK=z["bestK_atr"].astype(np.float32)
 acts=z["pnl_atr_actions"].astype(np.float32)
 state=z["state_feats"].astype(np.float32)
 ctxc=z["ctx_cont"].astype(np.float32)
 ctxk=z["ctx_cat"]
 actions_old=z["actions_old"].astype(np.int16)
 hour=ctxk[:,0].astype(np.int16)
 dow=ctxk[:,1].astype(np.int16)
 sess=ctxk[:,2].astype(np.int16)
 month=ctxk[:,3].astype(np.int32)
 atr=ctxc[:,3].astype(np.float32)
 n=base.size
 K=acts.shape[1]
 w=np.where(actions_old==BASELINE_ACTION_OLD)[0]
 if w.size==0:
  raise RuntimeError(("BASELINE_ACTION_NOT_IN_K",stream,int(BASELINE_ACTION_OLD),actions_old.tolist()))
 baseline_new=int(w[0])
 X=np.concatenate([state,ctxc,np.stack([hour.astype(np.float32),dow.astype(np.float32),sess.astype(np.float32)],axis=1)],axis=1).astype(np.float32)
 cat_idx=[X.shape[1]-3,X.shape[1]-2,X.shape[1]-1]
 params={"objective":"multiclass","num_class":int(K),"learning_rate":0.07,"num_leaves":63,"min_data_in_leaf":30,"feature_fraction":0.9,"bagging_fraction":0.9,"bagging_freq":1,"max_bin":255,"num_threads":2,"verbosity":-1,"seed":1337}
 m_sorted=np.unique(month); m_sorted.sort()
 per=int(np.ceil(float(TREES)/float(m_sorted.size))) if m_sorted.size else TREES
 rem=int(TREES)
 booster=None
 pred=np.full(n,baseline_new,np.int16)
 sanity_model_atr=acts[np.arange(n),pred.astype(np.int64)]
 sanity_usd=float(np.sum(usd(sanity_model_atr,atr)))
 base_usd=float(np.sum(usd(base,atr)))
 sanity_diff=float(sanity_usd-base_usd)
 rows=[]
 t0=time.perf_counter()
 for m in m_sorted.tolist():
  mm=(month==m)
  pred_idx=np.flatnonzero(mm & (keep==1))
  if booster is not None and pred_idx.size>0:
   p=booster.predict(X[pred_idx],num_iteration=booster.current_iteration())
   pred[pred_idx]=np.argmax(p,axis=1).astype(np.int16)
  model_atr=acts[mm,pred[mm].astype(np.int64)]
  au=atr[mm]
  b_usd=float(np.sum(usd(base[mm],au)))
  o_usd=float(np.sum(usd(bestK[mm],au)))
  m_usd=float(np.sum(usd(model_atr,au)))
  rows.append({"month":int(m),"n":int(mm.sum()),"n_pred":int(pred_idx.size),"base_usd":b_usd,"model_usd":m_usd,"oracleK_usd":o_usd,"uplift_usd":m_usd-b_usd,"model_oracle_pct":(m_usd/o_usd if abs(o_usd)>1e-12 else 0.0)})
  tr_idx=np.flatnonzero(mm & (keep==1))
  if rem>0 and tr_idx.size>=NMIN_TRAIN:
   yy=y[tr_idx].astype(np.int32)
   if np.unique(yy).size>=2:
    add=min(per,rem)
    ww=(bestK[tr_idx]-base[tr_idx]).astype(np.float32)
    ww=np.clip(ww,0.0,2.0)
    dtrain=lgb.Dataset(X[tr_idx],label=yy,weight=ww,categorical_feature=cat_idx,free_raw_data=True)
    booster=lgb.train(params,dtrain,num_boost_round=int(add),init_model=booster,keep_training_booster=True)
    rem-=int(add)
 rep=pd.DataFrame(rows)
 rep.to_csv(os.path.join(OUT_DIR,f"monthly_{stream}.csv"),index=False)
 used=int(TREES-rem)
 oracle_all=float(np.sum(usd(bestK,atr)))
 model_all=float(np.sum(usd(acts[np.arange(n),pred.astype(np.int64)],atr)))
 t1=time.perf_counter()
 if booster is not None:
  booster.save_model(os.path.join(OUT_DIR,f"model_{stream}.txt"))
 return {"stream":stream,"n":int(n),"K":int(K),"baseline_new":baseline_new,"trees_used":used,"train_sec":float(t1-t0),"base_usd":base_usd,"model_usd":model_all,"oracleK_usd":oracle_all,"uplift_usd":model_all-base_usd,"model_oracle_pct":(model_all/oracle_all if abs(oracle_all)>1e-12 else 0.0),"sanity_base_diff_usd":sanity_diff}
def main():
 files=sorted([f for f in os.listdir(IN_DIR) if f.startswith("datasetK_") and f.endswith(".npz")])
 if not files: raise RuntimeError(("NO_DATASETK",IN_DIR))
 meta={"threads":2,"trees":TREES,"nmin_train":NMIN_TRAIN,"baseline_old":BASELINE_ACTION_OLD,"fix":"pred default = baseline_new (mapped from actions_old)"}
 with open(os.path.join(OUT_DIR,"train_meta.json"),"w",encoding="utf-8") as f: json.dump(meta,f,ensure_ascii=False)
 print("ROOT",ROOT)
 print("IN_DIR",IN_DIR)
 print("OUT_DIR",OUT_DIR)
 print("THREADS",2,"TREES",TREES,"NMIN_TRAIN",NMIN_TRAIN,"BASELINE_OLD",BASELINE_ACTION_OLD)
 sums=[]
 for fn in files:
  stream=fn[len("datasetK_"):-4]
  z=np.load(os.path.join(IN_DIR,fn),allow_pickle=True)
  s=train_stream(stream,z)
  sums.append(s)
  print("STREAM",stream,"K",s["K"],"baseline_new",s["baseline_new"],"trees",s["trees_used"],"sec",fmt(s["train_sec"]),"SANITY_DIFF_USD",fmt(s["sanity_base_diff_usd"]),"BASE",fmt(s["base_usd"]),"MODEL",fmt(s["model_usd"]),"ORACLEK",fmt(s["oracleK_usd"]),"uplift",fmt(s["uplift_usd"]),"pct_oracle",fmt(s["model_oracle_pct"]))
 sumdf=pd.DataFrame(sums).sort_values("uplift_usd",ascending=False)
 sumdf.to_csv(os.path.join(OUT_DIR,"summary_streams.csv"),index=False)
 tot_base=float(sumdf["base_usd"].sum()); tot_model=float(sumdf["model_usd"].sum()); tot_or=float(sumdf["oracleK_usd"].sum())
 print("[11] SUMMARY_STREAMS")
 print(sumdf.to_string(index=False))
 print("[11] TOTAL","BASE",fmt(tot_base),"MODEL",fmt(tot_model),"ORACLEK",fmt(tot_or),"uplift",fmt(tot_model-tot_base),"pct_oracle",fmt((tot_model/tot_or if abs(tot_or)>1e-12 else 0.0)))
 print("[11] FILES summary_streams.csv monthly_*.csv model_*.txt train_meta.json")
if __name__=="__main__":
 main()
