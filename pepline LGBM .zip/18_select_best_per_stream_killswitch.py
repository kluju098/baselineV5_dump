﻿import os,sys
import numpy as np
import pandas as pd
ROOT=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
IN_DIR=os.path.join(ROOT,"LGBM","17","out")
OUT_DIR=os.path.join(ROOT,"LGBM","18","out")
os.makedirs(OUT_DIR,exist_ok=True)
def fmt(v):
 if isinstance(v,(int,np.integer)): return str(int(v))
 if isinstance(v,(float,np.floating)):
  x=float(v)
  if abs(x)>=1000: return f"{x:,.0f}".replace(","," ")
  if abs(x)>=100: return f"{x:.1f}"
  if abs(x)>=10: return f"{x:.2f}"
  return f"{x:.3f}"
 return str(v)
def main():
 fs=sorted([f for f in os.listdir(IN_DIR) if f.startswith("fw_q_") and f.endswith(".csv") and f!="fw_q_all.csv" and f!="fw_q_total.csv"])
 if not fs: raise RuntimeError(("NO_FW_Q_STREAM_FILES",IN_DIR))
 rows=[]
 for f in fs:
  stream=f[len("fw_q_"):-4]
  df=pd.read_csv(os.path.join(IN_DIR,f))
  g=df.groupby(["q","tau_min","budget"],as_index=False).agg(uplift_usd=("uplift_usd","sum"),base_usd=("base_usd","sum"),model_usd=("model_usd","sum"),oracleK_usd=("oracleK_usd","sum"),switch_rate=("switch_rate","mean"),hist_ready_rate=("hist_ready","mean"))
  g["pct_oracle"]=g["model_usd"]/np.where(np.abs(g["oracleK_usd"])>1e-12,g["oracleK_usd"],1.0)
  g=g.sort_values(["uplift_usd","switch_rate"],ascending=[False,True]).reset_index(drop=True)
  best=g.iloc[0].to_dict()
  best["stream"]=stream
  rows.append(best)
 best=pd.DataFrame(rows).sort_values("uplift_usd",ascending=False).reset_index(drop=True)
 best.to_csv(os.path.join(OUT_DIR,"best_params_per_stream.csv"),index=False)
 all_on=best.copy()
 pos_on=best[best["uplift_usd"]>0].copy()
 neg_off=best[best["uplift_usd"]<=0].copy()
 def agg(tag,df):
  base=float(df["base_usd"].sum()) if len(df) else 0.0
  model=float(df["model_usd"].sum()) if len(df) else 0.0
  upl=float(df["uplift_usd"].sum()) if len(df) else 0.0
  orc=float(df["oracleK_usd"].sum()) if len(df) else 0.0
  sw=float(df["switch_rate"].mean()) if len(df) else 0.0
  pr=float(model/orc) if abs(orc)>1e-12 else 0.0
  print("["+tag+"] base_usd",fmt(base),"model_usd",fmt(model),"uplift_usd",fmt(upl),"oracleK_usd",fmt(orc),"pct_oracle",fmt(pr),"avg_switch_rate",fmt(sw))
 agg("ALL_STREAMS_ON",all_on)
 agg("ONLY_POSITIVE_STREAMS_ON",pos_on)
 print("[PER_STREAM_BEST]")
 cols=["stream","q","tau_min","budget","uplift_usd","base_usd","model_usd","switch_rate","hist_ready_rate"]
 print(best[cols].to_string(index=False))
 if len(neg_off):
  print("[KILLSWITCH_OFF_STREAMS]",",".join(neg_off["stream"].tolist()))
 else:
  print("[KILLSWITCH_OFF_STREAMS] NONE")
 with open(os.path.join(OUT_DIR,"summary.json"),"w",encoding="utf-8") as f:
  j={"ROOT":ROOT,"IN_DIR":IN_DIR,"OUT_DIR":OUT_DIR,"all_on":all_on.to_dict(orient="records"),"pos_on":pos_on.to_dict(orient="records"),"off_streams":neg_off["stream"].tolist()}
  import json; json.dump(j,f,ensure_ascii=False)
 print("[18] FILES best_params_per_stream.csv summary.json")
if __name__=="__main__":
 main()
