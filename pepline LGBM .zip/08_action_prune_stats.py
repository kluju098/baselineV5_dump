﻿import os,sys,json
import numpy as np
import pandas as pd
ROOT=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
IN_DIR=os.path.join(ROOT,"LGBM","05","out")
OUT_DIR=os.path.join(ROOT,"LGBM","08","out")
os.makedirs(OUT_DIR,exist_ok=True)
os.environ["OMP_NUM_THREADS"]="2"
os.environ["OPENBLAS_NUM_THREADS"]="2"
os.environ["MKL_NUM_THREADS"]="2"
os.environ["VECLIB_MAXIMUM_THREADS"]="2"
os.environ["NUMEXPR_NUM_THREADS"]="2"
BASELINE_ACTION_IDX=10
COVER_TARGET=0.95
MIN_COUNT=25
TOPK_MAX=12
def fmt(x):
 if isinstance(x,(int,np.integer)): return str(int(x))
 if isinstance(x,(float,np.floating)):
  v=float(x)
  if abs(v)>=1000: return f"{v:,.0f}".replace(","," ")
  if abs(v)>=100: return f"{v:.1f}"
  if abs(v)>=10: return f"{v:.2f}"
  return f"{v:.3f}"
 return str(x)
def pick_actions(cnt,cover_target=0.95,min_count=25,topk_max=12,baseline_idx=10):
 order=np.argsort(-cnt)
 tot=float(cnt.sum()) if cnt.sum()>0 else 1.0
 chosen=[]
 csum=0.0
 for a in order.tolist():
  if cnt[a]<=0: break
  if len(chosen)<topk_max:
   chosen.append(int(a))
   csum+=float(cnt[a])
  if csum/tot>=cover_target and (len(chosen)>=1): break
 chosen=[a for a in chosen if cnt[a]>=min_count]
 if baseline_idx not in chosen: chosen.append(int(baseline_idx))
 chosen=sorted(set(chosen))
 cover=float(cnt[chosen].sum())/tot if tot>0 else 0.0
 return chosen,cover
def main():
 files=sorted([f for f in os.listdir(IN_DIR) if f.startswith("dataset32_full_") and f.endswith(".npz")])
 if not files: raise RuntimeError(("NO_DATASET32_FULL",IN_DIR))
 out_map={}
 all_rows=[]
 print("ROOT",ROOT)
 print("IN_DIR",IN_DIR)
 print("OUT_DIR",OUT_DIR)
 print("BASELINE_ACTION_IDX",BASELINE_ACTION_IDX,"COVER_TARGET",COVER_TARGET,"MIN_COUNT",MIN_COUNT,"TOPK_MAX",TOPK_MAX)
 for fn in files:
  stream=fn[len("dataset32_full_"):-4]
  z=np.load(os.path.join(IN_DIR,fn),allow_pickle=True)
  keep=z["keep"].astype(np.uint8)
  y=z["y"].astype(np.int16)
  base=z["base_atr"].astype(np.float32)
  best=z["best_atr"].astype(np.float32)
  acts=z["pnl_atr_actions"].astype(np.float32)
  km=(keep==1)
  n=int(base.size)
  nk=int(km.sum())
  if nk==0:
   out_map[stream]={"K":1,"actions":[BASELINE_ACTION_IDX],"cover":0.0,"unique_best":0,"n":n,"n_keep":nk}
   print("STREAM",stream,"n",n,"keep",nk,"SKIP_NO_KEEP")
   continue
  yy=y[km]
  cnt=np.bincount(yy,minlength=acts.shape[1]).astype(np.int64)
  uniq=int((cnt>0).sum())
  gain_all=(acts[km]-base[km,None]).astype(np.float32)
  mean_gain_action=gain_all.mean(axis=0).astype(np.float64)
  gain_best=(best[km]-base[km]).astype(np.float64)
  gain_when_best=np.zeros(acts.shape[1],np.float64)
  for a in range(acts.shape[1]):
   m=(yy==a)
   if m.any(): gain_when_best[a]=float(gain_best[m].mean())
  chosen,cover=pick_actions(cnt,COVER_TARGET,MIN_COUNT,TOPK_MAX,BASELINE_ACTION_IDX)
  out_map[stream]={"K":int(len(chosen)),"actions":chosen,"cover":float(cover),"unique_best":uniq,"n":n,"n_keep":nk}
  df=pd.DataFrame({"action":np.arange(acts.shape[1],dtype=np.int16),"best_count":cnt.astype(np.int64),"best_pct":(cnt/float(cnt.sum())).astype(np.float64),"mean_gain_atr_when_best":gain_when_best,"mean_gain_atr_overall":mean_gain_action})
  df=df.sort_values(["best_count","mean_gain_atr_when_best"],ascending=[False,False]).reset_index(drop=True)
  df.to_csv(os.path.join(OUT_DIR,f"action_stats_{stream}.csv"),index=False)
  top=df.head(12)
  print("STREAM",stream,"n",n,"keep",nk,"unique_best",uniq,"RECOMM_K",len(chosen),"cover",fmt(cover),"actions",json.dumps(chosen,ensure_ascii=False))
  print(top.to_string(index=False))
  all_rows.append(pd.DataFrame({"stream":[stream]*df.shape[0],"action":df["action"].to_numpy(),"best_count":df["best_count"].to_numpy(),"best_pct":df["best_pct"].to_numpy(),"mean_gain_atr_when_best":df["mean_gain_atr_when_best"].to_numpy(),"mean_gain_atr_overall":df["mean_gain_atr_overall"].to_numpy()}))
 pd.DataFrame([{"stream":k,**v} for k,v in out_map.items()]).to_csv(os.path.join(OUT_DIR,"actions_pruned_summary.csv"),index=False)
 with open(os.path.join(OUT_DIR,"actions_pruned.json"),"w",encoding="utf-8") as f: json.dump(out_map,f,ensure_ascii=False)
 if all_rows:
  pd.concat(all_rows,ignore_index=True).to_csv(os.path.join(OUT_DIR,"action_stats_all.csv"),index=False)
 print("[08] FILES actions_pruned.json actions_pruned_summary.csv action_stats_<stream>.csv action_stats_all.csv")
if __name__=="__main__":
 main()
