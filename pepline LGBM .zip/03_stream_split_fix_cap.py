﻿import os,json,sys
import numpy as np
import pandas as pd
from numba import njit
from tqdm import tqdm
USDPLN=3.54
LOT=0.01
ROOT=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
MM_ROOT=ROOT
OUT_DIR=os.path.join(ROOT,"LGBM","03","out")
PARAMS_JSON=os.path.join(ROOT,"params_sessions.json")
os.makedirs(OUT_DIR,exist_ok=True)
STREAMS=[("222","mid"),("223","mid"),("332","mid"),("333","mid"),("222","high"),("332","high")]
PRIORITY=["333_mid","332_high","332_mid","222_high","223_mid","222_mid"]
SESS=["ASIA","LONDON","NY","OFF"]
UTC_DENY=np.array([0,1,2,20,21,22,23],dtype=np.int16)
DENY_WAW_MID=np.array([5,6,10,14,21],dtype=np.int16)
DENY_WAW_HIGH=np.array([10],dtype=np.int16)
ADX_MID_HI=45.0
ADX_HIGH_HI=70.0
ATR_MIN_DEFAULT_MID=1.76
ATR_MIN_DEFAULT_HIGH=2.10
COST_MAX_DEFAULT=0.7
RSI_MID_HI_DEFAULT=80.0
RSI_HIGH_LO_DEFAULT=20.0
MFI_LO_DEFAULT=0.0
MFI_HI_DEFAULT=100.0
ADX_MID_LO_DEFAULT=20.0
ADX_HIGH_LO_DEFAULT=45.0
OVR={("332","mid"):{ "atr_min":1.90,"rsi_hi":85.0,"mfi_lo":20.0,"mfi_hi":100.0,"adx_lo":20.0,"cost_max":0.50},("333","mid"):{ "atr_min":1.85,"rsi_hi":80.0,"mfi_lo":0.0,"mfi_hi":90.0,"adx_lo":20.0,"cost_max":0.50}}
@njit
def trade_sim_reason(p,tp,sl,ts,td,be,tcap):
 stop=-1e9
 best=0.0
 cap=tcap
 if cap>599: cap=599
 for i in range(cap+1):
  x=float(p[i])
  if x>=tp: return tp,0,i
  if x<=-sl: return -sl,1,i
  if be>0.0 and best>=be and stop<0.0: stop=0.0
  if ts>0.0 and best>=ts:
   cand=best-td
   if cand>stop: stop=cand
  if stop>-1e8 and x<=stop:
   if abs(stop)<=1e-9: return 0.0,2,i
   return stop,3,i
  if x>best: best=x
 return float(p[cap]),4,cap
@njit
def max_dd(eq):
 mx=-1e18
 dd=0.0
 for v in eq:
  if v>mx: mx=v
  d=v-mx
  if d<dd: dd=d
 return dd
@njit
def daily_agg_sorted(day,pnl):
 n=day.size
 if n==0: return np.empty(0,np.int32),np.empty(0,np.float64)
 o=np.argsort(day)
 d=day[o]; x=pnl[o]
 out_d=np.empty(n,np.int32); out_s=np.empty(n,np.float64)
 k=0; cur=d[0]; s=0.0
 for i in range(n):
  if d[i]!=cur:
   out_d[k]=cur; out_s[k]=s; k+=1; cur=d[i]; s=x[i]
  else:
   s+=x[i]
 out_d[k]=cur; out_s[k]=s; k+=1
 return out_d[:k],out_s[:k]
@njit
def mean_std_ddof1(x):
 n=x.size
 if n<=1: return 0.0,0.0
 s=0.0
 for i in range(n): s+=x[i]
 mu=s/n
 v=0.0
 for i in range(n):
  d=x[i]-mu
  v+=d*d
 v=v/(n-1)
 return mu,np.sqrt(v)
@njit
def count_pos_neg_sum(pn):
 n=pn.size
 wp=0
 gw=0.0
 gl=0.0
 s=0.0
 for i in range(n):
  v=float(pn[i])
  s+=v
  if v>0.0:
   wp+=1
   gw+=v
  elif v<0.0:
   gl+=v
 return s,wp,gw,gl
def waw_dt(entry_ts_ms):
 return pd.to_datetime(entry_ts_ms,unit="ms",utc=True).tz_convert("Europe/Warsaw")
def waw_hour_day_month(entry_ts_ms):
 dt=waw_dt(entry_ts_ms)
 return dt.hour.astype(np.int16).to_numpy(),dt.strftime("%Y%m%d").astype(np.int32).to_numpy(),dt.strftime("%Y%m").astype(np.int32).to_numpy()
def session_id_waw(waw_h):
 s=np.full(waw_h.size,3,np.int16)
 m=(waw_h>=0)&(waw_h<=7); s[m]=0
 m=(waw_h>=8)&(waw_h<=14); s[m]=1
 m=(waw_h>=15)&(waw_h<=21); s[m]=2
 return s
def load_ds(ds):
 dd=os.path.join(MM_ROOT,ds)
 tp=os.path.join(dd,"trades.parquet")
 fp=os.path.join(dd,"pnl_net_atr_T599.f32")
 if not os.path.exists(tp): raise RuntimeError(("TRADES_NOT_FOUND",ds,tp))
 if not os.path.exists(fp): raise RuntimeError(("PNL_NOT_FOUND",ds,fp))
 t=pd.read_parquet(tp,columns=["trade_id","hour_utc","rsi","mfi","adx","atr","cost_atr","entry_ts_ms"])
 x=np.fromfile(fp,dtype=np.float32)
 n=len(t)
 if x.size!=n*600: raise RuntimeError(("PNL_SIZE_MISMATCH",ds,int(n),int(x.size)))
 return t,x.reshape(n,600)
def mask_stream(ds,reg,t):
 o=OVR.get((ds,reg),{})
 cost_max=float(o.get("cost_max",COST_MAX_DEFAULT))
 atr_min=float(o.get("atr_min",ATR_MIN_DEFAULT_MID if reg=="mid" else ATR_MIN_DEFAULT_HIGH))
 mfi_lo=float(o.get("mfi_lo",MFI_LO_DEFAULT))
 mfi_hi=float(o.get("mfi_hi",MFI_HI_DEFAULT))
 atr=t["atr"].to_numpy(dtype=np.float32)
 cost=t["cost_atr"].to_numpy(dtype=np.float32)
 cost_over=(cost/np.maximum(atr,1e-12)).astype(np.float32)
 if reg=="mid":
  adx_lo=float(o.get("adx_lo",ADX_MID_LO_DEFAULT))
  rsi_hi=float(o.get("rsi_hi",RSI_MID_HI_DEFAULT))
  adx=t["adx"].to_numpy(dtype=np.float32)
  rsi=t["rsi"].to_numpy(dtype=np.float32)
  adx_ok=(adx>=adx_lo)&(adx<ADX_MID_HI)
  rsi_ok=(rsi<=rsi_hi)
  deny=DENY_WAW_MID
 else:
  adx_lo=float(o.get("adx_lo",ADX_HIGH_LO_DEFAULT))
  rsi_lo=float(o.get("rsi_lo",RSI_HIGH_LO_DEFAULT))
  adx=t["adx"].to_numpy(dtype=np.float32)
  rsi=t["rsi"].to_numpy(dtype=np.float32)
  adx_ok=(adx>=adx_lo)&(adx<ADX_HIGH_HI)
  rsi_ok=(rsi>=rsi_lo)
  deny=DENY_WAW_HIGH
 entry_ms=t["entry_ts_ms"].to_numpy(dtype=np.int64)
 waw_h,day,month=waw_hour_day_month(entry_ms)
 utc_ok=~np.isin(t["hour_utc"].to_numpy(dtype=np.int16),UTC_DENY)
 waw_ok=~np.isin(waw_h,deny)
 cost_ok=((cost_over<=cost_max))
 atr_ok=(atr>=atr_min)
 mfi=t["mfi"].to_numpy(dtype=np.float32)
 mfi_ok=(mfi>=mfi_lo)&(mfi<=mfi_hi)
 return utc_ok&waw_ok&cost_ok&adx_ok&rsi_ok&atr_ok&mfi_ok,waw_h,day,month,atr
def _as6(v):
 if isinstance(v,(list,tuple)) and len(v)>=6:
  try: return [float(v[0]),float(v[1]),float(v[2]),float(v[3]),float(v[4]),int(v[5])]
  except: return None
 if isinstance(v,dict):
  if "tp" in v and "sl" in v and "ts" in v and "td" in v and "be" in v and "tcap" in v:
   try: return [float(v["tp"]),float(v["sl"]),float(v["ts"]),float(v["td"]),float(v["be"]),int(v["tcap"])]
   except: return None
  if "params" in v: return _as6(v["params"])
 return None
def load_params_map(path):
 with open(path,"r",encoding="utf-8") as f: j=json.load(f)
 pm={}
 if isinstance(j,dict):
  for k,v in j.items():
   x=_as6(v)
   if x is not None: pm[str(k)]=x
 return pm
def simulate_usd(keys,sessions,pnl_paths,atrs,pm):
 n=keys.size
 out_atr=np.empty(n,np.float32)
 for i in range(n):
  k=str(keys[i])+"_"+str(sessions[i])
  par=pm.get(k)
  if par is None: raise RuntimeError(("MISSING_PARAM",k,int(len(pm))))
  tp,sl,ts,td,be,tcap=par
  pa,_,_=trade_sim_reason(pnl_paths[i],tp,sl,ts,td,be,int(tcap))
  out_atr[i]=pa
 usd=out_atr.astype(np.float64)*atrs.astype(np.float64)*100.0*LOT
 return usd
def metrics(day,pn):
 d,ds=daily_agg_sorted(day,pn)
 eq=np.cumsum(ds)
 mdd=float(max_dd(eq))
 total,wp,gw,gl=count_pos_neg_sum(pn)
 wst=float(ds.min()) if ds.size else 0.0
 red=int((ds<0).sum())
 rr=float(total/abs(mdd)) if mdd<0 else 0.0
 mu,sd=mean_std_ddof1(ds.astype(np.float64))
 sharpe=(mu/sd)*np.sqrt(252.0) if sd>1e-12 else 0.0
 dn=ds[ds<0]
 ddn=float(np.sqrt(np.mean(dn.astype(np.float64)*dn.astype(np.float64)))) if dn.size else 0.0
 sortino=(mu/ddn)*np.sqrt(252.0) if ddn>1e-12 else 0.0
 mean_t=float(total/pn.size) if pn.size else 0.0
 _,std_t=mean_std_ddof1(pn.astype(np.float64))
 wr=float(wp/pn.size) if pn.size else 0.0
 return {"days":int(ds.size),"count":int(pn.size),"winrate":wr,"total_usd":float(total),"max_dd_usd":float(mdd),"worst_day_usd":float(wst),"rr_pnl_dd":float(rr),"sharpe_daily":float(sharpe),"sortino_daily":float(sortino),"mean_usd":float(mean_t),"std_usd":float(std_t),"gross_win_usd":float(gw),"gross_loss_usd":float(gl)}
def cap_priority(df):
 pr={s:i for i,s in enumerate(PRIORITY)}
 d=df.copy()
 d["rank"]=d["stream"].map(pr).astype(np.int16)
 d=d.sort_values(["entry_ts_ms","rank"],ascending=[True,True])
 d=d.drop_duplicates("entry_ts_ms",keep="first").drop(columns=["rank"])
 return d.reset_index(drop=True)
def main():
 pm=load_params_map(PARAMS_JSON)
 print("ROOT",ROOT)
 print("PARAMS_JSON_LOADED",int(len(pm)))
 rows=[]
 for ds,reg in tqdm(STREAMS,desc="load+filter"):
  t,p=load_ds(ds)
  m,waw_h,day,month,atr=mask_stream(ds,reg,t)
  idx=np.flatnonzero(m)
  stream=f"{ds}_{reg}"
  print("STREAM",stream,"after_filters",int(idx.size))
  if idx.size==0: continue
  sid=session_id_waw(waw_h[idx])
  sess=np.array([SESS[int(x)] for x in sid],dtype=object)
  rows.append(pd.DataFrame({"entry_ts_ms":t["entry_ts_ms"].to_numpy(dtype=np.int64)[idx],"day":day[idx].astype(np.int32),"month":month[idx].astype(np.int32),"waw_h":waw_h[idx].astype(np.int16),"session":sess,"key":np.array([stream]*idx.size,dtype=object),"atr":atr[idx].astype(np.float32),"pnl_path":list(p[idx]),"stream":np.array([stream]*idx.size,dtype=object)}))
 if not rows: raise RuntimeError("NO_TRADES_AFTER_FILTERS")
 allc=pd.concat(rows,ignore_index=True)
 allc.to_csv(os.path.join(OUT_DIR,"all_after_filters.csv"),index=False)
 vc=allc["stream"].value_counts().rename_axis("stream").reset_index(name="count_after_filters")
 vc.to_csv(os.path.join(OUT_DIR,"streams_counts_after_filters.csv"),index=False)
 pnl_paths_all=np.stack(allc["pnl_path"].to_list()).astype(np.float32)
 pn_raw=simulate_usd(allc["key"].to_numpy(dtype=object),allc["session"].to_numpy(dtype=object),pnl_paths_all,allc["atr"].to_numpy(dtype=np.float32),pm)
 raw_rows=[]
 for s in vc["stream"].tolist():
  m=(allc["stream"].to_numpy(dtype=object)==s)
  idx=np.flatnonzero(m)
  raw_rows.append({**metrics(allc["day"].to_numpy(dtype=np.int32)[idx],pn_raw[idx]),"stream":s,"scope":"RAW_NO_CAP"})
 raw_m=pd.DataFrame(raw_rows).sort_values(["total_usd"],ascending=False)
 raw_m.to_csv(os.path.join(OUT_DIR,"streams_metrics_RAW_NO_CAP.csv"),index=False)
 cap=cap_priority(allc)
 cap.to_csv(os.path.join(OUT_DIR,"cap_trades.csv"),index=False)
 vc2=cap["stream"].value_counts().rename_axis("stream").reset_index(name="count_chosen_cap")
 vc2.to_csv(os.path.join(OUT_DIR,"streams_counts_CHOSEN_CAP.csv"),index=False)
 pnl_paths_cap=np.stack(cap["pnl_path"].to_list()).astype(np.float32)
 pn_cap=simulate_usd(cap["key"].to_numpy(dtype=object),cap["session"].to_numpy(dtype=object),pnl_paths_cap,cap["atr"].to_numpy(dtype=np.float32),pm)
 cap_rows=[]
 for s in vc2["stream"].tolist():
  m=(cap["stream"].to_numpy(dtype=object)==s)
  idx=np.flatnonzero(m)
  cap_rows.append({**metrics(cap["day"].to_numpy(dtype=np.int32)[idx],pn_cap[idx]),"stream":s,"scope":"CHOSEN_CAP"})
 cap_m=pd.DataFrame(cap_rows).sort_values(["total_usd"],ascending=False)
 cap_m.to_csv(os.path.join(OUT_DIR,"streams_metrics_CHOSEN_CAP.csv"),index=False)
 a=dict(zip(vc["stream"],vc["count_after_filters"]))
 b=dict(zip(vc2["stream"],vc2["count_chosen_cap"]))
 diffs=[]
 for s in a.keys():
  if a.get(s,0)==b.get(s,0):
   ra=float(raw_m.loc[raw_m["stream"]==s,"total_usd"].values[0])
   ca=float(cap_m.loc[cap_m["stream"]==s,"total_usd"].values[0])
   diffs.append((s,abs(ra-ca),ra,ca))
 diffs=sorted(diffs,key=lambda x:-x[1])
 maxdiff=diffs[0][1] if diffs else 0.0
 bad=[d for d in diffs if d[1]>1e-6][:12]
 print("[03] OUT_DIR",OUT_DIR)
 print("[03] CAP_REMOVED",int(len(allc)-len(cap)),"OF",int(len(allc)))
 print("[03] COUNTS_AFTER_FILTERS")
 print(vc.to_string(index=False))
 print("[03] METRICS_RAW_NO_CAP TOP6")
 print(raw_m[["stream","count","total_usd","max_dd_usd","rr_pnl_dd","winrate","mean_usd"]].to_string(index=False))
 print("[03] COUNTS_CHOSEN_CAP")
 print(vc2.to_string(index=False))
 print("[03] METRICS_CHOSEN_CAP TOP6")
 print(cap_m[["stream","count","total_usd","max_dd_usd","rr_pnl_dd","winrate","mean_usd"]].to_string(index=False))
 print("[03] CHECK_MAX_ABS_DIFF_TOTAL_USD",("{:.12f}".format(float(maxdiff))))
 if bad:
  print("[03] CHECK_BAD_STREAMS (stream absdiff raw cap)")
  for s,ad,ra,ca in bad:
   print(s,("{:.12f}".format(float(ad))),("{:.6f}".format(float(ra))),("{:.6f}".format(float(ca))))
 print("[03] FILES streams_counts_after_filters.csv streams_metrics_RAW_NO_CAP.csv streams_counts_CHOSEN_CAP.csv streams_metrics_CHOSEN_CAP.csv cap_trades.csv all_after_filters.csv")
if __name__=="__main__":
 main()
