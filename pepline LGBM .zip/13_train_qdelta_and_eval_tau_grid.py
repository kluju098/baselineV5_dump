﻿import os,sys,time,json
import numpy as np
import pandas as pd
ROOT=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
IN_DIR=os.path.join(ROOT,"LGBM","09","out")
OUT_DIR=os.path.join(ROOT,"LGBM","13","out")
os.makedirs(OUT_DIR,exist_ok=True)
os.environ["OMP_NUM_THREADS"]="2"
os.environ["OPENBLAS_NUM_THREADS"]="2"
os.environ["MKL_NUM_THREADS"]="2"
os.environ["VECLIB_MAXIMUM_THREADS"]="2"
os.environ["NUMEXPR_NUM_THREADS"]="2"
LOT=0.01
BASELINE_OLD=10
TREES=800
NMIN_TRAIN_SMALL=40
NMIN_TRAIN=80
TAUS=np.array([0.00,0.01,0.02,0.03,0.05,0.08],np.float32)
import lightgbm as lgb
def fmt(v):
 if isinstance(v,(int,np.integer)): return str(int(v))
 if isinstance(v,(float,np.floating)):
  x=float(v)
  if abs(x)>=1000: return f"{x:,.0f}".replace(","," ")
  if abs(x)>=100: return f"{x:.1f}"
  if abs(x)>=10: return f"{x:.2f}"
  return f"{x:.3f}"
 return str(v)
def usd(pnl_atr,atr):
 return pnl_atr.astype(np.float64)*atr.astype(np.float64)*100.0*LOT
def train_stream(stream,z):
 keep=z["keep"].astype(np.uint8)
 base=z["base_atr"].astype(np.float32)
 bestK=z["bestK_atr"].astype(np.float32)
 acts=z["pnl_atr_actions"].astype(np.float32)
 state=z["state_feats"].astype(np.float32)
 ctxc=z["ctx_cont"].astype(np.float32)
 ctxk=z["ctx_cat"]
 actions_old=z["actions_old"].astype(np.int16)
 hour=ctxk[:,0].astype(np.int16)
 dow=ctxk[:,1].astype(np.int16)
 sess=ctxk[:,2].astype(np.int16)
 month=ctxk[:,3].astype(np.int32)
 atr=ctxc[:,3].astype(np.float32)
 n=base.size
 K=acts.shape[1]
 w=np.where(actions_old==BASELINE_OLD)[0]
 if w.size==0: raise RuntimeError(("BASELINE_NOT_IN_K",stream,int(BASELINE_OLD)))
 abase=int(w[0])
 X=np.concatenate([state,ctxc,np.stack([hour.astype(np.float32),dow.astype(np.float32),sess.astype(np.float32)],axis=1)],axis=1).astype(np.float32)
 cat_idx=[X.shape[1]-3,X.shape[1]-2,X.shape[1]-1, X.shape[1]]
 params={"objective":"huber","alpha":0.9,"learning_rate":0.05,"num_leaves":63,"min_data_in_leaf":50,"feature_fraction":0.9,"bagging_fraction":0.9,"bagging_freq":1,"max_bin":255,"num_threads":2,"verbosity":-1,"seed":1337}
 m_sorted=np.unique(month); m_sorted.sort()
 per=int(np.ceil(float(TREES)/float(m_sorted.size))) if m_sorted.size else TREES
 rem=int(TREES)
 booster=None
 pred=np.full(n,abase,np.int16)
 t0=time.perf_counter()
 rows=[]
 nmin=NMIN_TRAIN_SMALL if stream in ("222_high","332_high") else NMIN_TRAIN
 for m in m_sorted.tolist():
  mm=(month==m)
  dec_idx=np.flatnonzero(mm & (keep==1))
  if booster is not None and dec_idx.size>0:
   Xmm=X[dec_idx]
   Q=np.empty((dec_idx.size,K),np.float32)
   for a in range(K):
    a_col=np.full((dec_idx.size,1),float(a),np.float32)
    Xa=np.concatenate([Xmm,a_col],axis=1)
    Q[:,a]=booster.predict(Xa,num_iteration=booster.current_iteration()).astype(np.float32)
   q_base=Q[:,abase]
   best=np.argmax(Q,axis=1).astype(np.int16)
   q_best=Q[np.arange(best.size),best.astype(np.int64)]
   pred[dec_idx]=best
   pred[dec_idx][(q_best-q_base)<0.0]=abase
  tr_idx=np.flatnonzero(mm & (keep==1))
  if rem>0 and tr_idx.size>=nmin:
   Xr=np.repeat(X[tr_idx],K,axis=0)
   a=np.tile(np.arange(K,dtype=np.int16),tr_idx.size).astype(np.float32).reshape(-1,1)
   y=acts[tr_idx].reshape(-1).astype(np.float32)
   base_rep=np.repeat(acts[tr_idx,abase],K).astype(np.float32)
   delta=(y-base_rep).astype(np.float32)
   wgt=np.clip(np.maximum(delta,0.0),0.0,2.0)+0.02
   Xa=np.concatenate([Xr,a],axis=1).astype(np.float32)
   add=min(per,rem)
   dtrain=lgb.Dataset(Xa,label=delta,weight=wgt,categorical_feature=cat_idx,free_raw_data=True)
   booster=lgb.train(params,dtrain,num_boost_round=int(add),init_model=booster,keep_training_booster=True)
   rem-=int(add)
 t1=time.perf_counter()
 used=int(TREES-rem)
 if booster is not None: booster.save_model(os.path.join(OUT_DIR,f"qdelta_{stream}.txt"))
 return booster,{"stream":stream,"n":int(n),"K":int(K),"abase":int(abase),"trees_used":used,"train_sec":float(t1-t0),"base_usd":float(np.sum(usd(base,atr))),"oracleK_usd":float(np.sum(usd(bestK,atr)))},X,acts,abase,keep,month,atr,base,bestK
def eval_tau(booster,X,acts,abase,keep,month,atr,base,bestK,taus):
 n=base.size; K=acts.shape[1]
 out=[]
 pred=np.full(n,abase,np.int16)
 m_sorted=np.unique(month); m_sorted.sort()
 for tau in taus.tolist():
  pred[:]=abase
  for m in m_sorted.tolist():
   mm=(month==m)
   dec_idx=np.flatnonzero(mm & (keep==1))
   if booster is None or dec_idx.size==0: continue
   Xmm=X[dec_idx]
   Q=np.empty((dec_idx.size,K),np.float32)
   for a in range(K):
    a_col=np.full((dec_idx.size,1),float(a),np.float32)
    Xa=np.concatenate([Xmm,a_col],axis=1)
    Q[:,a]=booster.predict(Xa,num_iteration=booster.current_iteration()).astype(np.float32)
   q_base=Q[:,abase]
   best=np.argmax(Q,axis=1).astype(np.int16)
   q_best=Q[np.arange(best.size),best.astype(np.int64)]
   choose=(q_best-q_base)>=float(tau)
   pp=np.full(best.size,abase,np.int16)
   pp[choose]=best[choose]
   pred[dec_idx]=pp
  model_atr=acts[np.arange(n),pred.astype(np.int64)]
  b=float(np.sum(usd(base,atr)))
  m=float(np.sum(usd(model_atr,atr)))
  o=float(np.sum(usd(bestK,atr)))
  out.append({"tau":float(tau),"model_usd":m,"uplift_usd":m-b,"pct_oracle":(m/o if abs(o)>1e-12 else 0.0),"switch_rate":float(np.mean(pred!=abase))})
 return pd.DataFrame(out)
def main():
 files=sorted([f for f in os.listdir(IN_DIR) if f.startswith("datasetK_") and f.endswith(".npz")])
 if not files: raise RuntimeError(("NO_DATASETK",IN_DIR))
 print("ROOT",ROOT)
 print("IN_DIR",IN_DIR)
 print("OUT_DIR",OUT_DIR)
 print("THREADS",2,"TREES",TREES,"NMIN_TRAIN",NMIN_TRAIN,"NMIN_TRAIN_SMALL",NMIN_TRAIN_SMALL,"TAUS",json.dumps([float(x) for x in TAUS.tolist()]))
 sum_rows=[]
 best_rows=[]
 for fn in files:
  stream=fn[len("datasetK_"):-4]
  z=np.load(os.path.join(IN_DIR,fn),allow_pickle=True)
  booster,meta,X,acts,abase,keep,month,atr,base,bestK=train_stream(stream,z)
  df=eval_tau(booster,X,acts,abase,keep,month,atr,base,bestK,TAUS)
  df["stream"]=stream
  df.to_csv(os.path.join(OUT_DIR,f"tau_grid_{stream}.csv"),index=False)
  df2=df.sort_values(["uplift_usd","switch_rate"],ascending=[False,True]).head(1).iloc[0].to_dict()
  df2["base_usd"]=meta["base_usd"]; df2["oracleK_usd"]=meta["oracleK_usd"]; df2["K"]=meta["K"]; df2["trees_used"]=meta["trees_used"]; df2["train_sec"]=meta["train_sec"]
  best_rows.append(df2)
  sum_rows.append(meta)
  print("STREAM",stream,"K",meta["K"],"trees",meta["trees_used"],"sec",fmt(meta["train_sec"]),"BASE",fmt(meta["base_usd"]),"ORACLEK",fmt(meta["oracleK_usd"]))
  top=df.sort_values(["uplift_usd","switch_rate"],ascending=[False,True]).head(3)
  print(top.to_string(index=False))
 best=pd.DataFrame(best_rows)
 best.to_csv(os.path.join(OUT_DIR,"best_tau_by_stream.csv"),index=False)
 tot_base=float(best["base_usd"].sum()); tot_model=float(best["model_usd"].sum()); tot_or=float(best["oracleK_usd"].sum())
 best["model_minus_base"]=best["model_usd"]-best["base_usd"]
 print("[13] BEST_TAU_BY_STREAM")
 print(best[["stream","K","trees_used","tau","switch_rate","base_usd","model_usd","model_minus_base","pct_oracle"]].sort_values("model_minus_base",ascending=False).to_string(index=False))
 print("[13] TOTAL","BASE",fmt(tot_base),"MODEL",fmt(tot_model),"ORACLEK",fmt(tot_or),"uplift",fmt(tot_model-tot_base),"pct_oracle",fmt((tot_model/tot_or if abs(tot_or)>1e-12 else 0.0)))
 print("[13] FILES best_tau_by_stream.csv tau_grid_<stream>.csv qdelta_<stream>.txt")
if __name__=="__main__":
 main()
