﻿import os,sys,json,time
import numpy as np
import pandas as pd
import lightgbm as lgb
STREAMS=["222_high","222_mid","223_mid","332_high","332_mid","333_mid"]
def load_npz(path,stream):
 z=np.load(path,allow_pickle=False)
 need=["keep","y_e2","gain_atr","base_atr","bestK_atr","X","X_cat"]
 miss=[k for k in need if k not in z.files]
 if miss: raise RuntimeError(("NPZ_MISSING_KEYS",stream,miss,"have",list(z.files)))
 keep=z["keep"].astype(np.uint8,copy=False)
 y=z["y_e2"].astype(np.int8,copy=False)
 gain=z["gain_atr"].astype(np.float32,copy=False)
 base=z["base_atr"].astype(np.float32,copy=False)
 best=z["bestK_atr"].astype(np.float32,copy=False)
 X=z["X"].astype(np.float32,copy=False)
 Xc=z["X_cat"].astype(np.int32,copy=False)
 return keep,y,gain,base,best,X,Xc
def month_ids_from_cat(Xc):
 # ctx_cat layout from datasetK: [hour,dow,session_id,month_id]
 return Xc[:,3].astype(np.int32,copy=False)
def train_online(stream,keep,y,gain,base,best,X,Xc,trees,threads,min_hist_n,tau):
 m=month_ids_from_cat(Xc)
 mask=keep.astype(bool)
 idx=np.where(mask)[0]
 if idx.size==0: return None
 months=np.unique(m[idx])
 months.sort()
 params={
  "objective":"binary",
  "metric":["binary_logloss"],
  "num_threads":int(threads),
  "learning_rate":0.05,
  "num_leaves":31,
  "min_data_in_leaf":20,
  "feature_fraction":0.9,
  "bagging_fraction":0.9,
  "bagging_freq":1,
  "lambda_l2":1.0,
  "verbose":-1,
  "seed":12345
 }
 booster=None
 used_trees=0
 rep_rows=[]
 for mo in months:
  test_mask=mask & (m==mo)
  train_mask=mask & (m<mo)
  ntr=int(train_mask.sum()); nte=int(test_mask.sum())
  if nte==0: continue
  if ntr<min_hist_n:
   # not ready -> always hold baseline
   base_sum=float(np.sum(base[test_mask]))
   model_sum=base_sum
   oracle_sum=float(np.sum(best[test_mask]))
   uplift=float(model_sum-base_sum)
   rep_rows.append([stream,int(mo),ntr,nte,0.0,base_sum,model_sum,oracle_sum,uplift,0.0,0.0,0.0])
   continue
  dtrain=lgb.Dataset(X[train_mask],label=y[train_mask].astype(np.float32),free_raw_data=True)
  add=min(int(trees-used_trees),int(trees))
  if add<=0: add=50
  t0=time.time()
  booster=lgb.train(params,dtrain,num_boost_round=int(add),init_model=booster,keep_training_booster=True)
  used_trees+=int(add)
  train_sec=time.time()-t0
  # predict prob of switch
  p=booster.predict(X[test_mask])
  p=np.asarray(p,dtype=np.float32)
  act=(p>=tau).astype(np.uint8)
  base_sum=float(np.sum(base[test_mask]))
  oracle_sum=float(np.sum(best[test_mask]))
  # if act=1 -> take oracle(bestK), else baseline
  model_sum=float(np.sum(base[test_mask]*(1.0-act)+best[test_mask]*act))
  uplift=float(model_sum-base_sum)
  # diagnostics
  on_rate=float(np.mean(act)) if act.size else 0.0
  true_pos=float(np.mean((act==1) & (y[test_mask]==1))) if act.size else 0.0
  prec=float(np.sum((act==1) & (y[test_mask]==1))/max(1,np.sum(act==1))) if act.size else 0.0
  rep_rows.append([stream,int(mo),ntr,nte,train_sec,base_sum,model_sum,oracle_sum,uplift,on_rate,true_pos,prec])
 df=pd.DataFrame(rep_rows,columns=["stream","month","n_train","n_test","train_sec","base_atr_sum","model_atr_sum","oracleK_atr_sum","uplift_atr","switch_rate","tp_rate","precision"])
 return df,used_trees
def main(root):
 in_dir=os.path.join(root,"LGBM","22","out")
 out_dir=os.path.join(root,"LGBM","23","out")
 os.makedirs(out_dir,exist_ok=True)
 threads=int(os.environ.get("THREADS","2"))
 trees=int(os.environ.get("TREES","1000"))
 min_hist_n=int(os.environ.get("MIN_HIST_N","200"))
 tau=float(os.environ.get("TAU","0.5"))
 print("ROOT",root)
 print("IN_DIR",in_dir)
 print("OUT_DIR",out_dir)
 print("THREADS",threads,"TREES",trees,"MIN_HIST_N",min_hist_n,"TAU",tau)
 all_sum=[]
 all_month=[]
 for stream in STREAMS:
  p=os.path.join(in_dir,f"datasetE2_{stream}.npz")
  if not os.path.exists(p):
   print("MISSING",stream,p); continue
  keep,y,gain,base,best,X,Xc=load_npz(p,stream)
  out=train_online(stream,keep,y,gain,base,best,X,Xc,trees,threads,min_hist_n,tau)
  if out is None:
   print("STREAM",stream,"EMPTY"); continue
  df,used=out
  df.to_csv(os.path.join(out_dir,f"online_e2_{stream}.csv"),index=False)
  base_total=float(df["base_atr_sum"].sum())
  model_total=float(df["model_atr_sum"].sum())
  oracle_total=float(df["oracleK_atr_sum"].sum())
  uplift=float(df["uplift_atr"].sum())
  sw=float(np.average(df["switch_rate"].values,weights=np.maximum(1,df["n_test"].values)))
  print("STREAM",stream,"used_trees",used,"BASE_ATR",f"{base_total:.6f}","MODEL_ATR",f"{model_total:.6f}","UPLIFT_ATR",f"{uplift:.6f}","ORACLEK_ATR",f"{oracle_total:.6f}","avg_switch",f"{sw:.6f}","months",df.shape[0])
  all_sum.append([stream,used,base_total,model_total,uplift,oracle_total,sw,df.shape[0]])
  all_month.append(df)
 if all_sum:
  s=pd.DataFrame(all_sum,columns=["stream","trees_used","base_atr_sum","model_atr_sum","uplift_atr_sum","oracleK_atr_sum","avg_switch_rate","months"])
  s.to_csv(os.path.join(out_dir,"summary_streams.csv"),index=False)
  base=float(s["base_atr_sum"].sum()); model=float(s["model_atr_sum"].sum()); uplift=float(s["uplift_atr_sum"].sum()); oracle=float(s["oracleK_atr_sum"].sum())
  sw=float(np.average(s["avg_switch_rate"].values,weights=np.maximum(1,s["months"].values)))
  print("[23] TOTAL_ATR BASE",f"{base:.6f}","MODEL",f"{model:.6f}","UPLIFT",f"{uplift:.6f}","ORACLEK",f"{oracle:.6f}","avg_switch",f"{sw:.6f}")
  pd.concat(all_month,ignore_index=True).to_csv(os.path.join(out_dir,"online_all.csv"),index=False)
  meta={"threads":threads,"trees":trees,"min_hist_n":min_hist_n,"tau":tau}
  with open(os.path.join(out_dir,"meta.json"),"w",encoding="utf-8") as f: json.dump(meta,f,indent=2)
  print("[23] FILES summary_streams.csv online_e2_<stream>.csv online_all.csv meta.json")
 else:
  print("[23] NO_STREAMS")
if __name__=="__main__":
 root=os.environ.get("ROOT")
 if not root: raise RuntimeError("SET_ROOT_ENV")
 main(root)
