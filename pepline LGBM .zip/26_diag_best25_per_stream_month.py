﻿import os,sys,json,time
import numpy as np,pandas as pd
import lightgbm as lgb
STREAMS=["222_high","222_mid","223_mid","332_high","332_mid","333_mid"]
BASELINE_OLD=10
TREES_CAP=1500
MIN_HIST_N=80
TAU=0.35
ADD_PER_MONTH=200
MIN_LEAF=40
NUM_LEAVES=31
def _read_meta(m):
    try:
        if isinstance(m,np.ndarray) and m.size==1:
            s=m.reshape(-1)[0]
            if isinstance(s,bytes): s=s.decode("utf-8")
            return json.loads(str(s))
        if isinstance(m,(bytes,bytearray)): return json.loads(m.decode("utf-8"))
    except Exception:
        return {}
    return {}
def _renumber_cat_cols(Xc):
    Xc=np.array(Xc,copy=True)
    for j in range(Xc.shape[1]):
        col=Xc[:,j].astype(np.int64)
        uniq=np.unique(col)
        Xc[:,j]=np.searchsorted(uniq,col)
    return Xc.astype(np.int32)
def baseline_new_index(actions_old):
    w=np.where(actions_old==BASELINE_OLD)[0]
    return int(w[0]) if w.size else 0
def load_npz(path):
    d=np.load(path,allow_pickle=False)
    keys=set(d.files)
    need=["keep","pnl_atr_actions","actions_old","X","X_cat","y_e2","y_bestK"]
    miss=[k for k in need if k not in keys]
    if miss: raise RuntimeError(("NPZ_MISSING_KEYS",os.path.basename(path),miss,sorted(list(keys))))
    keep=d["keep"].astype(np.uint8).reshape(-1)
    X=d["X"].astype(np.float32)
    Xc=np.array(d["X_cat"],copy=False)
    if Xc.ndim==1: Xc=Xc.reshape(-1,1)
    meta=_read_meta(d["meta"]) if "meta" in keys else {}
    month_pos=int(meta.get("month_pos",Xc.shape[1]-1)) if isinstance(meta,dict) else (Xc.shape[1]-1)
    if month_pos<0 or month_pos>=Xc.shape[1]: month_pos=Xc.shape[1]-1
    month_raw=Xc[:,month_pos].astype(np.int32)
    Xc=_renumber_cat_cols(Xc)
    X_full=np.concatenate([X,Xc.astype(np.float32)],axis=1)
    cat_idx=np.arange(X.shape[1],X.shape[1]+Xc.shape[1],dtype=np.int32)
    y_e2=d["y_e2"].astype(np.int32).reshape(-1)
    y_bestK=d["y_bestK"].astype(np.int32).reshape(-1)
    pnl=d["pnl_atr_actions"].astype(np.float32)
    actions_old=d["actions_old"].astype(np.int32).reshape(-1)
    if keep.size!=X_full.shape[0] or keep.size!=y_e2.size or keep.size!=pnl.shape[0] or keep.size!=y_bestK.size:
        raise RuntimeError(("NPZ_SHAPE_MISMATCH",os.path.basename(path),{"keep":keep.shape,"X_full":X_full.shape,"y_e2":y_e2.shape,"y_bestK":y_bestK.shape,"pnl":pnl.shape}))
    if pnl.shape[1]!=actions_old.size:
        raise RuntimeError(("NPZ_ACTIONS_MISMATCH",os.path.basename(path),{"pnl_cols":int(pnl.shape[1]),"actions_old":int(actions_old.size)}))
    return keep,X_full,cat_idx,month_raw,y_e2,y_bestK,pnl,actions_old
def online_fw_monthly(keep,X_full,cat_idx,month_raw,y_e2,y_bestK,pnl,actions_old,params):
    bn=baseline_new_index(actions_old)
    use=(keep>0)
    months=np.unique(month_raw[use]);months=np.sort(months.astype(np.int32))
    trees_used=0
    booster=None
    out=[]
    for m in months:
        test_idx=np.where((month_raw==m)&use)[0]
        if test_idx.size==0: continue
        train_idx=np.where((month_raw<m)&use)[0]
        train_n=int(train_idx.size)
        if train_n>=int(MIN_HIST_N) and trees_used<int(TREES_CAP):
            add=min(int(ADD_PER_MONTH),int(TREES_CAP-trees_used))
            dtrain=lgb.Dataset(X_full[train_idx],label=y_e2[train_idx],categorical_feature=cat_idx.tolist(),free_raw_data=True)
            if booster is None: booster=lgb.train(params,dtrain,num_boost_round=int(add))
            else: booster=lgb.train(params,dtrain,num_boost_round=int(add),init_model=booster,keep_training_booster=True)
            trees_used+=int(add)
        if booster is None:
            sw=np.zeros(test_idx.size,dtype=np.uint8)
        else:
            p=booster.predict(X_full[test_idx]).astype(np.float32)
            sw=(p>=float(TAU)).astype(np.uint8)
        chosen=np.where(sw>0,y_bestK[test_idx],bn).astype(np.int32)
        base=float(pnl[test_idx,bn].sum())
        model=float(pnl[test_idx,chosen].sum())
        uplift=float(model-base)
        out.append([int(m),int(test_idx.size),base,model,uplift,float(sw.mean()),int(sw.sum()),int(trees_used)])
    return out
def main(root):
    IN_DIR=os.environ.get("IN_DIR",os.path.join(root,"LGBM","22","out"))
    OUT_DIR=os.environ.get("OUT_DIR",os.path.join(root,"LGBM","26","out"))
    THREADS=int(os.environ.get("THREADS","2"))
    os.makedirs(OUT_DIR,exist_ok=True)
    print("ROOT",root)
    print("IN_DIR",IN_DIR)
    print("OUT_DIR",OUT_DIR)
    print("BEST_FROM_25 min_leaf",MIN_LEAF,"num_leaves",NUM_LEAVES,"trees_cap",TREES_CAP,"min_hist_n",MIN_HIST_N,"tau",TAU,"add_per_month",ADD_PER_MONTH,"threads",THREADS)
    params={"objective":"binary","learning_rate":0.05,"num_leaves":int(NUM_LEAVES),"min_data_in_leaf":int(MIN_LEAF),"feature_fraction":0.9,"bagging_fraction":0.9,"bagging_freq":1,"lambda_l2":1.0,"verbosity":-1,"num_threads":int(THREADS),"max_bin":255}
    all_rows=[]
    stream_sum=[]
    for s in STREAMS:
        keep,X_full,cat_idx,month_raw,y_e2,y_bestK,pnl,actions_old=load_npz(os.path.join(IN_DIR,f"datasetE2_{s}.npz"))
        rows=online_fw_monthly(keep,X_full,cat_idx,month_raw,y_e2,y_bestK,pnl,actions_old,params=params)
        for r in rows: all_rows.append([s]+r)
        if rows:
            base=sum(x[2] for x in rows);model=sum(x[3] for x in rows);upl=sum(x[4] for x in rows)
            sw_mean=float(np.mean([x[5] for x in rows]))
            stream_sum.append([s,int(sum(x[1] for x in rows)),float(base),float(model),float(upl),sw_mean,int(rows[0][7] if rows else 0),int(rows[-1][7] if rows else 0)])
        print("STREAM",s,"months",len(rows),"base_atr",f"{sum(x[2] for x in rows):.6f}","model_atr",f"{sum(x[3] for x in rows):.6f}","uplift_atr",f"{sum(x[4] for x in rows):.6f}")
    df=pd.DataFrame(all_rows,columns=["stream","month","n","base_atr","model_atr","uplift_atr","switch_rate","switch_n","trees_used"])
    df.to_csv(os.path.join(OUT_DIR,"per_month.csv"),index=False)
    ssum=pd.DataFrame(stream_sum,columns=["stream","n_total","base_atr_sum","model_atr_sum","uplift_atr_sum","mean_month_switch_rate","trees_used_first_month","trees_used_last_month"])
    ssum=ssum.sort_values("uplift_atr_sum",ascending=False).reset_index(drop=True)
    ssum.to_csv(os.path.join(OUT_DIR,"per_stream.csv"),index=False)
    if len(df):
        g=df.groupby("month",as_index=False).agg(n=("n","sum"),base_atr=("base_atr","sum"),model_atr=("model_atr","sum"),uplift_atr=("uplift_atr","sum"),switch_rate=("switch_rate","mean"))
        g=g.sort_values("month").reset_index(drop=True)
        g.to_csv(os.path.join(OUT_DIR,"all_streams_by_month.csv"),index=False)
        tot_base=float(g["base_atr"].sum());tot_model=float(g["model_atr"].sum());tot_upl=float(g["uplift_atr"].sum())
    else:
        tot_base=tot_model=tot_upl=0.0
        g=pd.DataFrame(columns=["month","n","base_atr","model_atr","uplift_atr","switch_rate"])
    meta={"best25":{"min_leaf":MIN_LEAF,"num_leaves":NUM_LEAVES,"trees_cap":TREES_CAP,"min_hist_n":MIN_HIST_N,"tau":TAU,"add_per_month":ADD_PER_MONTH,"threads":THREADS},"total":{"base_atr":tot_base,"model_atr":tot_model,"uplift_atr":tot_upl}}
    with open(os.path.join(OUT_DIR,"meta.json"),"w",encoding="utf-8") as f: json.dump(meta,f,ensure_ascii=False,indent=2)
    print("[26] TOTAL_ATR base",f"{tot_base:.6f}","model",f"{tot_model:.6f}","uplift",f"{tot_upl:.6f}")
    print("[26] TOP_STREAMS_BY_UPLIFT")
    print(ssum.head(10).to_string(index=False))
    print("[26] FILES per_stream.csv per_month.csv all_streams_by_month.csv meta.json")
if __name__=="__main__":
    root=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
    main(root)
