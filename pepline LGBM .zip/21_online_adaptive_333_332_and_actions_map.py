﻿import os,sys,json
import numpy as np
import pandas as pd
ROOT=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
IN_DIR=os.path.join(ROOT,"LGBM","09","out")
IN17=os.path.join(ROOT,"LGBM","17","out")
IN18=os.path.join(ROOT,"LGBM","18","out")
IN05=os.path.join(ROOT,"LGBM","05","out")
IN08=os.path.join(ROOT,"LGBM","08","out")
OUT_DIR=os.path.join(ROOT,"LGBM","21","out")
os.makedirs(OUT_DIR,exist_ok=True)
os.environ["OMP_NUM_THREADS"]="2"
os.environ["OPENBLAS_NUM_THREADS"]="2"
os.environ["MKL_NUM_THREADS"]="2"
os.environ["VECLIB_MAXIMUM_THREADS"]="2"
os.environ["NUMEXPR_NUM_THREADS"]="2"
LOT=0.01
BASELINE_OLD=10
TREES=800
NMIN_TRAIN=80
STREAMS=["333_mid","332_mid"]
import lightgbm as lgb
def fmt(v):
 if isinstance(v,(int,np.integer)): return str(int(v))
 if isinstance(v,(float,np.floating)):
  x=float(v)
  if abs(x)>=1000: return f"{x:,.0f}".replace(","," ")
  if abs(x)>=100: return f"{x:.1f}"
  if abs(x)>=10: return f"{x:.2f}"
  return f"{x:.3f}"
 return str(v)
def load_actions_map():
 cand=[]
 cand.append(os.path.join(IN_DIR,"gates_actionsK.json"))
 cand.append(os.path.join(IN08,"actions_pruned.json"))
 cand.append(os.path.join(IN05,"actions32.json"))
 for p in cand:
  if os.path.exists(p):
   with open(p,"r",encoding="utf-8") as f:
    j=json.load(f)
   return p,j
 return None,{}
def make_X(z):
 state=z["state_feats"].astype(np.float32)
 ctxc=z["ctx_cont"].astype(np.float32)
 ctxk=z["ctx_cat"]
 hour=ctxk[:,0].astype(np.int16)
 dow=ctxk[:,1].astype(np.int16)
 sess=ctxk[:,2].astype(np.int16)
 X=np.concatenate([state,ctxc,np.stack([hour.astype(np.float32),dow.astype(np.float32),sess.astype(np.float32)],axis=1)],axis=1).astype(np.float32)
 return X
def corr(a,b):
 a=a.astype(np.float64); b=b.astype(np.float64)
 if a.size<3: return 0.0
 am=a-a.mean(); bm=b-b.mean()
 da=np.sqrt(np.mean(am*am)); db=np.sqrt(np.mean(bm*bm))
 if da<1e-12 or db<1e-12: return 0.0
 return float(np.mean(am*bm)/(da*db))
def train_booster(X,acts,tr_idx,K,abase,booster,add):
 params={"objective":"huber","alpha":0.9,"learning_rate":0.05,"num_leaves":63,"min_data_in_leaf":50,"feature_fraction":0.9,"bagging_fraction":0.9,"bagging_freq":1,"max_bin":255,"num_threads":2,"verbosity":-1,"seed":1337}
 Xr=np.repeat(X[tr_idx],K,axis=0)
 a=np.tile(np.arange(K,dtype=np.int16),tr_idx.size).astype(np.float32).reshape(-1,1)
 y=acts[tr_idx].reshape(-1).astype(np.float32)
 base_rep=np.repeat(acts[tr_idx,abase],K).astype(np.float32)
 delta_tr=(y-base_rep).astype(np.float32)
 wgt=np.clip(np.maximum(delta_tr,0.0),0.0,2.0)+0.02
 Xa=np.concatenate([Xr,a],axis=1).astype(np.float32)
 cat_idx=[Xa.shape[1]-4,Xa.shape[1]-3,Xa.shape[1]-2,Xa.shape[1]-1]
 dtrain=lgb.Dataset(Xa,label=delta_tr,weight=wgt,categorical_feature=cat_idx,free_raw_data=True)
 booster=lgb.train(params,dtrain,num_boost_round=int(add),init_model=booster,keep_training_booster=True)
 return booster
def predict_Q(booster,Xm,K):
 Q=np.empty((Xm.shape[0],K),np.float32)
 for a in range(K):
  a_col=np.full((Xm.shape[0],1),float(a),np.float32)
  Xa=np.concatenate([Xm,a_col],axis=1)
  Q[:,a]=booster.predict(Xa,num_iteration=booster.current_iteration()).astype(np.float32)
 return Q
def main():
 bp=os.path.join(IN18,"best_params_per_stream.csv")
 if not os.path.exists(bp): raise RuntimeError(("MISSING",bp))
 best=pd.read_csv(bp).set_index("stream")
 amap_path,amap=load_actions_map()
 print("ROOT",ROOT)
 print("IN_DIR",IN_DIR)
 print("OUT_DIR",OUT_DIR)
 print("[21] ACTIONS_MAP_SOURCE",amap_path if amap_path else "NONE")
 use_ids=set([0,1,2,3,4,5,8,9,10,12,13,14,15,28,29])
 if isinstance(amap,dict):
  keys=list(amap.keys())
  shown=[]
  for k in keys:
   try:
    ki=int(k)
    if ki in use_ids:
     shown.append((ki,amap[k]))
   except:
    pass
  if shown:
   shown=sorted(shown,key=lambda t:t[0])
   print("[21] ACTIONS_MAP_SELECTED")
   for ki,v in shown:
    s=json.dumps(v,ensure_ascii=False)
    print("action",ki,s)
 rows=[]
 for stream in STREAMS:
  path=os.path.join(IN_DIR,f"datasetK_{stream}.npz")
  if not os.path.exists(path): raise RuntimeError(("MISSING_DATASETK",stream,path))
  z=np.load(path,allow_pickle=True)
  keep=z["keep"].astype(np.uint8)
  acts=z["pnl_atr_actions"].astype(np.float32)
  actions_old=z["actions_old"].astype(np.int16)
  ctxk=z["ctx_cat"]
  month=ctxk[:,3].astype(np.int32)
  K=acts.shape[1]
  w=np.where(actions_old==BASELINE_OLD)[0]
  if w.size==0: raise RuntimeError(("BASELINE_NOT_IN_K",stream,int(BASELINE_OLD)))
  abase=int(w[0])
  X=make_X(z)
  q=float(best.loc[stream,"q"]); tau_min=float(best.loc[stream,"tau_min"]); budget_best=float(best.loc[stream,"budget"])
  m_sorted=np.unique(month); m_sorted.sort()
  per=int(np.ceil(float(TREES)/max(1,int(m_sorted.size))))
  booster=None
  rem=int(TREES)
  hist_marg=[]
  budget_next=0.0
  outm=[]
  for mi,m in enumerate(m_sorted.tolist()):
   mm=(month==m)
   dec_idx=np.flatnonzero(mm & (keep==1))
   uplift_atr=0.0
   sw_rate=0.0
   mean_d_sw=0.0
   pctp_sw=0.0
   cm=0.0
   top_s=""
   if booster is not None and dec_idx.size>0 and budget_next>0.0:
    Xm=X[dec_idx]
    Q=predict_Q(booster,Xm,K)
    q_base=Q[:,abase]
    best_a=np.argmax(Q,axis=1).astype(np.int16)
    q_best=Q[np.arange(best_a.size),best_a.astype(np.int64)]
    margin=(q_best-q_base).astype(np.float32)
    hist=np.concatenate(hist_marg).astype(np.float32) if len(hist_marg) else None
    thr=float(np.quantile(hist,q)) if hist is not None and hist.size else 1e9
    eff=max(thr,float(tau_min)) if hist is not None and hist.size else float(tau_min)
    elig=(margin>=eff)
    order=np.argsort(-margin)
    k=int(np.floor(float(budget_next)*float(best_a.size)))
    pred=np.full(best_a.size,abase,np.int16)
    if k>0:
     pick=order[:k]
     choose=np.zeros(best_a.size,np.bool_)
     choose[pick]=True
     choose &= elig
     pred[choose]=best_a[choose]
    base_atr=acts[dec_idx,abase].astype(np.float32)
    pred_atr=acts[dec_idx,pred.astype(np.int64)].astype(np.float32)
    delta=(pred_atr-base_atr).astype(np.float32)
    uplift_atr=float(np.sum(delta))
    sw=(pred!=abase)
    sw_rate=float(np.mean(sw)) if sw.size else 0.0
    if np.any(sw):
     dsw=delta[sw]
     mean_d_sw=float(np.mean(dsw)) if dsw.size else 0.0
     pctp_sw=float(np.mean(dsw>0)) if dsw.size else 0.0
     cm=corr(margin[sw],dsw)
    vc=np.bincount(pred.astype(np.int64),minlength=K)
    top=np.argsort(-vc)[:5]
    top_s=",".join([f"{int(actions_old[i])}:{int(vc[i])}" for i in top if vc[i]>0])
    hist_marg.append(margin.copy())
   uplift_usd=float(uplift_atr)*100.0*LOT
   outm.append({"stream":stream,"month":int(m),"n_dec":int(dec_idx.size),"budget_used":float(budget_next),"uplift_usd":uplift_usd,"switch_rate":sw_rate,"mean_delta_atr_sw":mean_d_sw,"pct_delta_pos_sw":pctp_sw,"corr_margin_delta":cm,"top_actions":top_s})
   if uplift_usd<0.0:
    budget_next=0.0
   else:
    budget_next=float(budget_best)
   tr_months=m_sorted[:mi+1]
   tr_idx=np.flatnonzero(np.isin(month,tr_months) & (keep==1))
   if rem>0 and tr_idx.size>=NMIN_TRAIN:
    add=min(per,rem)
    booster=train_booster(X,acts,tr_idx,K,abase,booster,add)
    rem-=int(add)
  df=pd.DataFrame(outm)
  df.to_csv(os.path.join(OUT_DIR,f"online_adaptive_{stream}.csv"),index=False)
  tot=float(df["uplift_usd"].sum())
  on=float(df.loc[df["budget_used"]>0,"uplift_usd"].sum())
  rows.append({"stream":stream,"months":int(df.shape[0]),"budget_best":budget_best,"total_uplift_usd":tot,"uplift_when_on_usd":on,"on_rate":float(np.mean(df["budget_used"]>0))})
  print("[21] STREAM",stream,"BEST(q,tau,budget)",q,tau_min,budget_best)
  print(df.to_string(index=False))
 summ=pd.DataFrame(rows)
 summ.to_csv(os.path.join(OUT_DIR,"summary.csv"),index=False)
 print("[21] SUMMARY")
 print(summ.to_string(index=False))
 print("[21] FILES online_adaptive_333_mid.csv online_adaptive_332_mid.csv summary.csv")
if __name__=="__main__":
 main()
