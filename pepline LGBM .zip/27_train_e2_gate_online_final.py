﻿import os,json,time
import numpy as np
import pandas as pd
import lightgbm as lgb
STREAMS=["222_high","222_mid","223_mid","332_high","332_mid","333_mid"]
def _load_npz(path):
  z=np.load(path,allow_pickle=True); keys=set(z.files)
  if "X" in keys and "y_e2" in keys and "base_atr" in keys and "gain_atr" in keys:
    X=z["X"].astype(np.float32)
    if "X_cat" in keys:
      Xc=z["X_cat"].astype(np.float32)
      X=np.concatenate([X,Xc],axis=1)
    y=z["y_e2"].astype(np.int8)
    keep=z["keep"].astype(np.uint8) if "keep" in keys else np.ones(X.shape[0],np.uint8)
    base=z["base_atr"].astype(np.float32)
    gain=z["gain_atr"].astype(np.float32)
    return X,y,keep,base,gain,{"keys":sorted(list(keys)),"has_x_cat":("X_cat" in keys),"x_dim":int(X.shape[1])}
  if "state_feats" in keys and "ctx_cont" in keys and "ctx_cat" in keys and "y" in keys:
    X=np.concatenate([z["state_feats"].astype(np.float32),z["ctx_cont"].astype(np.float32),z["ctx_cat"].astype(np.float32)],axis=1)
    y=z["y"].astype(np.int16); keep=z["keep"].astype(np.uint8) if "keep" in keys else np.ones(X.shape[0],np.uint8)
    base=z["base_atr"].astype(np.float32) if "base_atr" in keys else np.zeros(X.shape[0],np.float32)
    gain=(z["bestK_atr"].astype(np.float32)-base) if "bestK_atr" in keys else np.zeros(X.shape[0],np.float32)
    return X,(y!=0).astype(np.int8),keep,base,gain,{"keys":sorted(list(keys)),"has_x_cat":False,"x_dim":int(X.shape[1])}
  raise RuntimeError(("NPZ_UNSUPPORTED_KEYS",os.path.basename(path),sorted(list(keys))))
def _infer_cat_cols(X,meta):
  d=X.shape[1]
  if meta.get("has_x_cat",False): cat_cols=list(range(d-4,d)); month_col=d-1; return cat_cols,month_col
  if d>=21: cat_cols=list(range(d-4,d)); month_col=d-1; return cat_cols,month_col
  if d>=4: cat_cols=list(range(d-4,d)); month_col=d-1; return cat_cols,month_col
  return [],None
def _remap_cats(X,cat_cols):
  maps={}
  X2=X.copy()
  for c in cat_cols:
    v=X2[:,c].astype(np.int64)
    uniq=np.unique(v)
    mp={int(k):i for i,k in enumerate(uniq.tolist())}
    maps[str(c)]=mp
    X2[:,c]=np.vectorize(mp.get,otypes=[np.int64])(v).astype(np.float32)
  return X2,maps
def train_online(stream,in_dir,out_dir,threads,trees_cap,add_per_month,min_hist_n,tau,num_leaves,min_leaf):
  p=os.path.join(in_dir,f"datasetE2_{stream}.npz")
  X,y,keep,base,gain,meta=_load_npz(p)
  cat_cols,month_col=_infer_cat_cols(X,meta)
  if month_col is None: raise RuntimeError(("NO_MONTH_COL",stream,meta.get("x_dim"),meta.get("keys")))
  X,cat_maps=_remap_cats(X,cat_cols) if cat_cols else (X,{})
  months=np.unique(X[:,month_col].astype(np.int64)); months.sort()
  rows=[]; trees_used_by_month=[]
  for i,m in enumerate(months):
    idx_m=np.where((X[:,month_col].astype(np.int64)==m) & (keep==1))[0]
    idx_hist=np.where((X[:,month_col].astype(np.int64)<m) & (keep==1))[0]
    trees=min(trees_cap,int(i*add_per_month)); trees_used_by_month.append(trees)
    if idx_m.size==0:
      rows.append((int(m),0,0.0,0.0,0.0,0.0,0.0)); continue
    base_sum=float(base[idx_m].sum())
    if trees<=0 or idx_hist.size<min_hist_n:
      model_sum=base_sum; rows.append((int(m),int(idx_m.size),base_sum,model_sum,0.0,0.0,0.0)); continue
    Xh=X[idx_hist]; yh=y[idx_hist]; Xm=X[idx_m]
    dtrain=lgb.Dataset(Xh,label=yh,categorical_feature=cat_cols,free_raw_data=True)
    params={"objective":"binary","metric":"None","verbosity":-1,"num_threads":int(threads),
            "learning_rate":0.05,"num_leaves":int(num_leaves),"min_data_in_leaf":int(min_leaf),
            "feature_fraction":1.0,"bagging_fraction":1.0,"bagging_freq":0,"max_bin":255}
    booster=lgb.train(params,dtrain,num_boost_round=int(trees))
    pr=booster.predict(Xm)
    sw=(pr>=tau).astype(np.uint8)
    model_sum=float((base[idx_m] + sw*gain[idx_m]).sum())
    rows.append((int(m),int(idx_m.size),base_sum,model_sum,model_sum-base_sum,float(sw.mean()),float(pr.mean())))
  dfm=pd.DataFrame(rows,columns=["month","n","base_atr","model_atr","uplift_atr","switch_rate","mean_p"])
  dfm.to_csv(os.path.join(out_dir,f"per_month_{stream}.csv"),index=False)
  full_idx=np.where(keep==1)[0]
  if full_idx.size>=min_hist_n:
    dtrain=lgb.Dataset(X[full_idx],label=y[full_idx],categorical_feature=cat_cols,free_raw_data=True)
    params={"objective":"binary","metric":"None","verbosity":-1,"num_threads":int(threads),
            "learning_rate":0.05,"num_leaves":int(num_leaves),"min_data_in_leaf":int(min_leaf),
            "feature_fraction":1.0,"bagging_fraction":1.0,"bagging_freq":0,"max_bin":255}
    booster=lgb.train(params,dtrain,num_boost_round=int(trees_cap))
    booster.save_model(os.path.join(out_dir,"models",f"model_e2_{stream}.txt"))
  with open(os.path.join(out_dir,"models",f"cat_maps_{stream}.json"),"w",encoding="utf-8") as f:
    json.dump({"cat_cols":cat_cols,"month_col":int(month_col),"maps":cat_maps,"npz_keys":meta.get("keys",[]),"x_dim":meta.get("x_dim")},f,ensure_ascii=False)
  tot_base=float(dfm["base_atr"].sum()); tot_model=float(dfm["model_atr"].sum())
  return {"stream":stream,"months":int(len(months)),"n_total":int(full_idx.size),"base_atr_sum":tot_base,"model_atr_sum":tot_model,
          "uplift_atr_sum":tot_model-tot_base,"mean_month_switch_rate":float(dfm["switch_rate"].mean()) if len(dfm) else 0.0,
          "trees_used_first_month":int(trees_used_by_month[0] if trees_used_by_month else 0),
          "trees_used_last_month":int(trees_used_by_month[-1] if trees_used_by_month else 0)}
def main(root):
  IN_DIR=os.environ.get("IN_DIR",os.path.join(root,"LGBM","22","out"))
  OUT_DIR=os.environ.get("OUT_DIR",os.path.join(root,"LGBM","27","out"))
  THREADS=int(os.environ.get("THREADS","2"))
  TREES_CAP=int(os.environ.get("TREES_CAP","1500"))
  ADD_PER_MONTH=int(os.environ.get("ADD_PER_MONTH","200"))
  MIN_HIST_N=int(os.environ.get("MIN_HIST_N","80"))
  TAU=float(os.environ.get("TAU","0.35"))
  NUM_LEAVES=int(os.environ.get("NUM_LEAVES","31"))
  MIN_LEAF=int(os.environ.get("MIN_LEAF","40"))
  os.makedirs(OUT_DIR,exist_ok=True); os.makedirs(os.path.join(OUT_DIR,"models"),exist_ok=True)
  print("ROOT",root); print("IN_DIR",IN_DIR); print("OUT_DIR",OUT_DIR)
  print("THREADS",THREADS,"TREES_CAP",TREES_CAP,"ADD_PER_MONTH",ADD_PER_MONTH,"MIN_HIST_N",MIN_HIST_N,"TAU",TAU,"NUM_LEAVES",NUM_LEAVES,"MIN_LEAF",MIN_LEAF)
  t0=time.time()
  per=[]; all_month=[]
  for s in STREAMS:
    r=train_online(s,IN_DIR,OUT_DIR,THREADS,TREES_CAP,ADD_PER_MONTH,MIN_HIST_N,TAU,NUM_LEAVES,MIN_LEAF)
    per.append(r)
    df=pd.read_csv(os.path.join(OUT_DIR,f"per_month_{s}.csv"))
    df.insert(0,"stream",s)
    all_month.append(df)
    print("STREAM",s,"months",r["months"],"base_atr",f'{r["base_atr_sum"]:.6f}',"model_atr",f'{r["model_atr_sum"]:.6f}',"uplift_atr",f'{r["uplift_atr_sum"]:.6f}')
  ps=pd.DataFrame(per).sort_values("uplift_atr_sum",ascending=False)
  ps.to_csv(os.path.join(OUT_DIR,"per_stream.csv"),index=False)
  pd.concat(all_month,ignore_index=True).to_csv(os.path.join(OUT_DIR,"all_streams_by_month.csv"),index=False)
  tot_base=float(ps["base_atr_sum"].sum()); tot_model=float(ps["model_atr_sum"].sum())
  meta={"config":{"trees_cap":TREES_CAP,"add_per_month":ADD_PER_MONTH,"min_hist_n":MIN_HIST_N,"tau":TAU,"num_leaves":NUM_LEAVES,"min_leaf":MIN_LEAF,"threads":THREADS},
        "total":{"base_atr":tot_base,"model_atr":tot_model,"uplift_atr":tot_model-tot_base},
        "elapsed_sec":time.time()-t0}
  with open(os.path.join(OUT_DIR,"meta.json"),"w",encoding="utf-8") as f: json.dump(meta,f,ensure_ascii=False,indent=2)
  print("[27] TOTAL_ATR base",f"{tot_base:.6f}","model",f"{tot_model:.6f}","uplift",f"{(tot_model-tot_base):.6f}")
  print("[27] TOP_STREAMS_BY_UPLIFT")
  cols=["stream","n_total","base_atr_sum","model_atr_sum","uplift_atr_sum","mean_month_switch_rate","trees_used_first_month","trees_used_last_month"]
  print(ps[cols].head(12).to_string(index=False))
  print("[27] FILES per_stream.csv per_month_<stream>.csv all_streams_by_month.csv meta.json models\\model_e2_<stream>.txt models\\cat_maps_<stream>.json")
if __name__=="__main__":
  import sys
  root=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
  main(root)
