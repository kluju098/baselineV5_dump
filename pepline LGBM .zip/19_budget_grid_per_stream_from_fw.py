﻿import os,sys
import numpy as np
import pandas as pd
ROOT=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
IN17=os.path.join(ROOT,"LGBM","17","out")
IN18=os.path.join(ROOT,"LGBM","18","out")
OUT_DIR=os.path.join(ROOT,"LGBM","19","out")
os.makedirs(OUT_DIR,exist_ok=True)
BUDGET_GRID=np.array([0.01,0.02,0.03,0.05,0.08,0.10,0.15,0.20],np.float32)
RISKY=set(["333_mid","332_mid"])
def fmt(v):
 if isinstance(v,(int,np.integer)): return str(int(v))
 if isinstance(v,(float,np.floating)):
  x=float(v)
  if abs(x)>=1000: return f"{x:,.0f}".replace(","," ")
  if abs(x)>=100: return f"{x:.1f}"
  if abs(x)>=10: return f"{x:.2f}"
  return f"{x:.3f}"
 return str(v)
def main():
 bp=os.path.join(IN18,"best_params_per_stream.csv")
 if not os.path.exists(bp): raise RuntimeError(("MISSING",bp))
 best=pd.read_csv(bp)
 out=[]
 for r in best.itertuples(index=False):
  stream=str(r.stream)
  q=float(r.q); tau_min=float(r.tau_min)
  fw=os.path.join(IN17,f"fw_q_{stream}.csv")
  df=pd.read_csv(fw)
  g=df.groupby(["q","tau_min","budget"],as_index=False)["uplift_usd"].sum()
  g=g[(np.isclose(g["q"],q)) & (np.isclose(g["tau_min"],tau_min))].copy()
  if stream in RISKY:
   grid=BUDGET_GRID[BUDGET_GRID<=0.10]
  else:
   grid=BUDGET_GRID
  picks=[]
  for b in grid.tolist():
   x=g[np.isclose(g["budget"],float(b))]
   if len(x)==0: continue
   picks.append((float(b),float(x["uplift_usd"].iloc[0])))
  if not picks:
   out.append({"stream":stream,"q":q,"tau_min":tau_min,"budget":float(r.budget),"uplift_usd":float(r.uplift_usd)})
   continue
  picks=sorted(picks,key=lambda t:t[1],reverse=True)
  bbest,ubest=picks[0]
  out.append({"stream":stream,"q":q,"tau_min":tau_min,"budget":bbest,"uplift_usd":ubest})
 sel=pd.DataFrame(out).sort_values("uplift_usd",ascending=False).reset_index(drop=True)
 sel.to_csv(os.path.join(OUT_DIR,"best_budget_per_stream.csv"),index=False)
 total=float(sel["uplift_usd"].sum())
 print("ROOT",ROOT)
 print("IN17",IN17)
 print("IN18",IN18)
 print("[19] BEST_BUDGET_PER_STREAM")
 print(sel.to_string(index=False))
 print("[19] TOTAL_UPLIFT_USD",fmt(total))
 print("[19] FILES best_budget_per_stream.csv")
if __name__=="__main__":
 main()
