﻿import os,sys,json
import numpy as np
import pandas as pd
from numba import njit
from tqdm import tqdm
os.environ["OMP_NUM_THREADS"]="1"
os.environ["OPENBLAS_NUM_THREADS"]="1"
os.environ["MKL_NUM_THREADS"]="1"
os.environ["VECLIB_MAXIMUM_THREADS"]="1"
os.environ["NUMEXPR_NUM_THREADS"]="1"
USDPLN=3.54
LOT=0.01
ROOT=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
OUT_DIR=os.path.join(ROOT,"LGBM","05","out")
PARAMS_JSON=os.path.join(ROOT,"params_sessions.json")
os.makedirs(OUT_DIR,exist_ok=True)
STREAMS=[("222","mid"),("223","mid"),("332","mid"),("333","mid"),("222","high"),("332","high")]
SESS=["ASIA","LONDON","NY","OFF"]
UTC_DENY=np.array([0,1,2,20,21,22,23],dtype=np.int16)
DENY_WAW_MID=np.array([5,6,10,14,21],dtype=np.int16)
DENY_WAW_HIGH=np.array([10],dtype=np.int16)
ADX_MID_HI=45.0
ADX_HIGH_HI=70.0
ATR_MIN_DEFAULT_MID=1.76
ATR_MIN_DEFAULT_HIGH=2.10
COST_MAX_DEFAULT=0.7
RSI_MID_HI_DEFAULT=80.0
RSI_HIGH_LO_DEFAULT=20.0
MFI_LO_DEFAULT=0.0
MFI_HI_DEFAULT=100.0
ADX_MID_LO_DEFAULT=20.0
ADX_HIGH_LO_DEFAULT=45.0
OVR={("332","mid"):{ "atr_min":1.90,"rsi_hi":85.0,"mfi_lo":20.0,"mfi_hi":100.0,"adx_lo":20.0,"cost_max":0.50},("333","mid"):{ "atr_min":1.85,"rsi_hi":80.0,"mfi_lo":0.0,"mfi_hi":90.0,"adx_lo":20.0,"cost_max":0.50}}
THR_MOVE_ATR=0.05
K=32
TSM=np.array([0.5,0.75,1.0,1.25],dtype=np.float32)
TDM=np.array([0.5,0.75,1.0,1.25],dtype=np.float32)
A_ts=np.empty(K,np.float32);A_td=np.empty(K,np.float32);A_be=np.empty(K,np.uint8)
k=0
for i in range(4):
 for j in range(4):
  A_ts[k]=TSM[i];A_td[k]=TDM[j];A_be[k]=0;k+=1
for i in range(4):
 for j in range(4):
  A_ts[k]=TSM[i];A_td[k]=TDM[j];A_be[k]=1;k+=1
def fmt(x):
 if isinstance(x,(int,np.integer)): return str(int(x))
 if isinstance(x,(float,np.floating)):
  v=float(x)
  if abs(v)>=1000: return f"{v:,.0f}".replace(","," ")
  if abs(v)>=100: return f"{v:.1f}"
  if abs(v)>=10: return f"{v:.2f}"
  return f"{v:.3f}"
 return str(x)
def waw_dt(entry_ts_ms):
 return pd.to_datetime(entry_ts_ms,unit="ms",utc=True).tz_convert("Europe/Warsaw")
def waw_time_feats(entry_ms):
 dt=waw_dt(entry_ms)
 h=dt.hour.astype(np.int16).to_numpy()
 dow=dt.dayofweek.astype(np.int16).to_numpy()
 day=dt.strftime("%Y%m%d").astype(np.int32).to_numpy()
 month=dt.strftime("%Y%m").astype(np.int32).to_numpy()
 return h,dow,day,month
def session_id_waw(waw_h):
 s=np.full(waw_h.size,3,np.int16)
 m=(waw_h>=0)&(waw_h<=7);s[m]=0
 m=(waw_h>=8)&(waw_h<=14);s[m]=1
 m=(waw_h>=15)&(waw_h<=21);s[m]=2
 return s
def load_ds(ds):
 dd=os.path.join(ROOT,ds)
 tp=os.path.join(dd,"trades.parquet")
 fp=os.path.join(dd,"pnl_net_atr_T599.f32")
 if not os.path.exists(tp): raise RuntimeError(("TRADES_NOT_FOUND",ds,tp))
 if not os.path.exists(fp): raise RuntimeError(("PNL_NOT_FOUND",ds,fp))
 t=pd.read_parquet(tp,columns=["trade_id","hour_utc","rsi","mfi","adx","atr","cost_atr","entry_ts_ms"])
 x=np.fromfile(fp,dtype=np.float32)
 n=len(t)
 if x.size!=n*600: raise RuntimeError(("PNL_SIZE_MISMATCH",ds,int(n),int(x.size)))
 return t,x.reshape(n,600)
def mask_stream(ds,reg,t):
 o=OVR.get((ds,reg),{})
 cost_max=float(o.get("cost_max",COST_MAX_DEFAULT))
 atr_min=float(o.get("atr_min",ATR_MIN_DEFAULT_MID if reg=="mid" else ATR_MIN_DEFAULT_HIGH))
 mfi_lo=float(o.get("mfi_lo",MFI_LO_DEFAULT))
 mfi_hi=float(o.get("mfi_hi",MFI_HI_DEFAULT))
 atr=t["atr"].to_numpy(dtype=np.float32)
 cost=t["cost_atr"].to_numpy(dtype=np.float32)
 cost_over=(cost/np.maximum(atr,1e-12)).astype(np.float32)
 if reg=="mid":
  adx_lo=float(o.get("adx_lo",ADX_MID_LO_DEFAULT))
  rsi_hi=float(o.get("rsi_hi",RSI_MID_HI_DEFAULT))
  adx=t["adx"].to_numpy(dtype=np.float32)
  rsi=t["rsi"].to_numpy(dtype=np.float32)
  adx_ok=(adx>=adx_lo)&(adx<ADX_MID_HI)
  rsi_ok=(rsi<=rsi_hi)
  deny=DENY_WAW_MID
 else:
  adx_lo=float(o.get("adx_lo",ADX_HIGH_LO_DEFAULT))
  rsi_lo=float(o.get("rsi_lo",RSI_HIGH_LO_DEFAULT))
  adx=t["adx"].to_numpy(dtype=np.float32)
  rsi=t["rsi"].to_numpy(dtype=np.float32)
  adx_ok=(adx>=adx_lo)&(adx<ADX_HIGH_HI)
  rsi_ok=(rsi>=rsi_lo)
  deny=DENY_WAW_HIGH
 entry_ms=t["entry_ts_ms"].to_numpy(dtype=np.int64)
 waw_h,dow,day,month=waw_time_feats(entry_ms)
 utc_ok=~np.isin(t["hour_utc"].to_numpy(dtype=np.int16),UTC_DENY)
 waw_ok=~np.isin(waw_h,deny)
 cost_ok=(cost_over<=cost_max)
 atr_ok=(atr>=atr_min)
 mfi=t["mfi"].to_numpy(dtype=np.float32)
 mfi_ok=(mfi>=mfi_lo)&(mfi<=mfi_hi)
 return utc_ok&waw_ok&cost_ok&adx_ok&rsi_ok&atr_ok&mfi_ok,waw_h,dow,day,month,atr,cost_over
def load_params_map(path):
 with open(path,"r",encoding="utf-8") as f: j=json.load(f)
 pm={}
 for k,v in j.items():
  if isinstance(v,dict) and "tp" in v and "sl" in v and "ts" in v and "td" in v and "be" in v and "tcap" in v:
   pm[str(k)]=[float(v["tp"]),float(v["sl"]),float(v["ts"]),float(v["td"]),float(v["be"]),int(v["tcap"])]
 return pm
@njit
def find_i0(p,thr):
 for i in range(p.size):
  x=p[i]
  if x<0: x=-x
  if x>=thr: return i
 return 0
@njit
def prefix_state(p,i0,tp,sl,ts,td,be):
 stop=-1e9
 best=0.0
 worst=0.0
 mean=0.0
 m2=0.0
 up=0
 sc=0
 last_d=0.0
 prev_d=0.0
 prev_s=0
 n=0
 for i in range(i0+1):
  x=float(p[i])
  if x>=tp: return 0,best,stop,worst,mean,m2,up,sc,last_d,prev_d,n
  if x<=-sl: return 0,best,stop,worst,mean,m2,up,sc,last_d,prev_d,n
  if be>0.0 and best>=be and stop<0.0: stop=0.0
  if ts>0.0 and best>=ts:
   cand=best-td
   if cand>stop: stop=cand
  if stop>-1e8 and x<=stop:
   return 0,best,stop,worst,mean,m2,up,sc,last_d,prev_d,n
  if x>best: best=x
  if x<worst: worst=x
  if i>0:
   d=float(p[i]-p[i-1])
   prev_d=last_d
   last_d=d
   n+=1
   if d>0.0: up+=1
   s=1 if d>0.0 else (-1 if d<0.0 else 0)
   if prev_s!=0 and s!=0 and s!=prev_s: sc+=1
   if s!=0: prev_s=s
   delta=d-mean
   mean+=delta/n
   m2+=delta*(d-mean)
 return 1,best,stop,worst,mean,m2,up,sc,last_d,prev_d,n
@njit
def sim_from(p,start_i,tp,sl,ts,td,be,tcap,best0,stop0):
 stop=stop0
 best=best0
 cap=tcap
 if cap>599: cap=599
 if start_i>cap: return float(p[cap])
 for i in range(start_i,cap+1):
  x=float(p[i])
  if x>=tp: return tp
  if x<=-sl: return -sl
  if be>0.0 and best>=be and stop<0.0: stop=0.0
  if ts>0.0 and best>=ts:
   cand=best-td
   if cand>stop: stop=cand
  if stop>-1e8 and x<=stop:
   if abs(stop)<=1e-9: return 0.0
   return stop
  if x>best: best=x
 return float(p[cap])
@njit
def trade_sim_pnl(p,tp,sl,ts,td,be,tcap):
 stop=-1e9
 best=0.0
 cap=tcap
 if cap>599: cap=599
 for i in range(cap+1):
  x=float(p[i])
  if x>=tp: return tp
  if x<=-sl: return -sl
  if be>0.0 and best>=be and stop<0.0: stop=0.0
  if ts>0.0 and best>=ts:
   cand=best-td
   if cand>stop: stop=cand
  if stop>-1e8 and x<=stop:
   if abs(stop)<=1e-9: return 0.0
   return stop
  if x>best: best=x
 return float(p[cap])
@njit
def build_full(pnl,tp,sl,ts,td,be,tcap,thr,A_ts,A_td,A_be):
 n=pnl.shape[0]
 base=np.empty(n,np.float32)
 best=np.empty(n,np.float32)
 y=np.empty(n,np.uint8)
 keep=np.empty(n,np.uint8)
 feats=np.empty((n,12),np.float32)
 acts=np.empty((n,A_ts.size),np.float32)
 for j in range(n):
  p=pnl[j]
  b=trade_sim_pnl(p,tp[j],sl[j],ts[j],td[j],be[j],tcap[j])
  base[j]=b
  i0=find_i0(p,thr)
  ok,best0,stop0,worst0,mean,m2,up,sc,last_d,prev_d,nn=prefix_state(p,i0,tp[j],sl[j],ts[j],td[j],be[j])
  if ok==0:
   best[j]=b
   y[j]=np.uint8(0)
   keep[j]=np.uint8(0)
   for f in range(12): feats[j,f]=0.0
   for a in range(A_ts.size): acts[j,a]=b
   continue
  std=0.0
  if nn>1 and m2>0.0: std=np.sqrt(m2/(nn-1))
  cur=float(p[i0])
  dd=best0-cur
  rng=best0-worst0
  upf=float(up)/float(nn) if nn>0 else 0.0
  scf=float(sc)/float(nn) if nn>0 else 0.0
  st=stop0
  if st<-1e8: st=-10.0
  feats[j,0]=cur;feats[j,1]=best0;feats[j,2]=worst0;feats[j,3]=dd;feats[j,4]=rng
  feats[j,5]=last_d;feats[j,6]=prev_d;feats[j,7]=mean;feats[j,8]=std;feats[j,9]=upf;feats[j,10]=scf;feats[j,11]=st
  bestv=-1e9
  besta=0
  for a in range(A_ts.size):
   ts2=ts[j]*A_ts[a]
   td2=td[j]*A_td[a]
   if td2<0.05: td2=0.05
   be2=0.0 if A_be[a]==1 else be[j]
   pv=sim_from(p,i0,tp[j],sl[j],ts2,td2,be2,tcap[j],best0,stop0)
   acts[j,a]=pv
   if pv>bestv:
    bestv=pv
    besta=a
  best[j]=bestv
  y[j]=np.uint8(besta)
  keep[j]=np.uint8(1)
 return base,best,y,keep,feats,acts
def usd_from_atr(pnl_atr,atr):
 return pnl_atr.astype(np.float64)*atr.astype(np.float64)*100.0*LOT
def main():
 pm=load_params_map(PARAMS_JSON)
 feat_names=["cur_atr","best_atr","worst_atr","dd_from_best_atr","range_atr","d1_atr","d2_atr","mean_d_atr","std_d_atr","up_frac","signchg_frac","stop_atr"]
 meta={"K":int(K),"A_ts":A_ts.tolist(),"A_td":A_td.tolist(),"A_be":A_be.tolist(),"thr_move_atr":float(THR_MOVE_ATR),"no_t_feature":True,"note":"labels use future (oracle) but features prefix-only"}
 with open(os.path.join(OUT_DIR,"actions32.json"),"w",encoding="utf-8") as f: json.dump(meta,f,ensure_ascii=False)
 with open(os.path.join(OUT_DIR,"state_feature_names.json"),"w",encoding="utf-8") as f: json.dump(feat_names,f,ensure_ascii=False)
 print("ROOT",ROOT)
 print("PARAMS_JSON_LOADED",int(len(pm)))
 print("DECISION_EVENT","first abs(pnl_atr)>=0.05 ; no t feature (no sec_elapsed, no i0 used as feature)")
 rows=[]
 for ds,reg in tqdm(STREAMS,desc="build_dataset32_full"):
  t,p=load_ds(ds)
  m,waw_h,dow,day,month,atr,cost_over=mask_stream(ds,reg,t)
  idx=np.flatnonzero(m)
  stream=f"{ds}_{reg}"
  print("STREAM",stream,"after_filters",int(idx.size))
  if idx.size==0: continue
  sid=session_id_waw(waw_h[idx])
  tp=np.empty(idx.size,np.float32);sl=np.empty(idx.size,np.float32);ts=np.empty(idx.size,np.float32);td=np.empty(idx.size,np.float32);be=np.empty(idx.size,np.float32);tcap=np.empty(idx.size,np.int16)
  for i in range(idx.size):
   ss=SESS[int(sid[i])]
   key=stream+"_"+ss
   par=pm.get(key)
   if par is None: raise RuntimeError(("MISSING_PARAM",key,int(len(pm))))
   tp[i]=np.float32(par[0]);sl[i]=np.float32(par[1]);ts[i]=np.float32(par[2]);td[i]=np.float32(par[3]);be[i]=np.float32(par[4]);tcap[i]=np.int16(par[5])
  pnl=p[idx].astype(np.float32)
  base_atr,best_atr,y,keep,feats,acts=build_full(pnl,tp,sl,ts,td,be,tcap,np.float32(THR_MOVE_ATR),A_ts,A_td,A_be)
  atr2=atr[idx].astype(np.float32)
  base_usd=float(np.sum(usd_from_atr(base_atr,atr2)))
  best_usd=float(np.sum(usd_from_atr(best_atr,atr2)))
  delta_atr=(best_atr-base_atr).astype(np.float32)
  mean_delta=float(np.mean(delta_atr.astype(np.float64)))
  pct10=float(np.mean((delta_atr>=0.10).astype(np.float64)))
  kept=int(np.sum(keep))
  rows.append({"stream":stream,"count":int(idx.size),"base_usd":base_usd,"best_usd":best_usd,"delta_usd":float(best_usd-base_usd),"mean_delta_atr":mean_delta,"pct_ge_0_10":pct10,"kept_for_ds":kept})
  ctx_cont=np.stack([t["rsi"].to_numpy(dtype=np.float32)[idx],t["mfi"].to_numpy(dtype=np.float32)[idx],t["adx"].to_numpy(dtype=np.float32)[idx],atr2,cost_over[idx].astype(np.float32)],axis=1).astype(np.float32)
  ctx_cat=np.stack([waw_h[idx].astype(np.int16),dow[idx].astype(np.int16),sid.astype(np.int16),month[idx].astype(np.int32)],axis=1)
  np.savez_compressed(os.path.join(OUT_DIR,f"dataset32_full_{stream}.npz"),
   keep=keep.astype(np.uint8),y=y.astype(np.uint8),
   base_atr=base_atr.astype(np.float32),best_atr=best_atr.astype(np.float32),
   state_feats=feats.astype(np.float32),
   pnl_atr_actions=acts.astype(np.float32),
   ctx_cont=ctx_cont,ctx_cat=ctx_cat,
   feat_state=np.array(feat_names,dtype=object),
   feat_ctx_cont=np.array(["rsi","mfi","adx","atr","cost_over_atr"],dtype=object),
   feat_ctx_cat=np.array(["hour_waw","dow_waw","session_id","month_waw"],dtype=object)
  )
  print("DATASET",stream,"BASE_USD",fmt(base_usd),"ORACLE_USD",fmt(best_usd),"DELTA_USD",fmt(best_usd-base_usd),"mean_delta_atr",fmt(mean_delta),"pct>=0.10",fmt(pct10),"kept",kept)
 sumdf=pd.DataFrame(rows).sort_values("best_usd",ascending=False)
 sumdf.to_csv(os.path.join(OUT_DIR,"oracle_summary_stream.csv"),index=False)
 print("[05] OUT_DIR",OUT_DIR)
 print("[05] ORACLE_SUMMARY_STREAMS")
 print(sumdf.to_string(index=False))
 print("[05] FILES oracle_summary_stream.csv actions32.json dataset32_full_*.npz state_feature_names.json")
if __name__=="__main__":
 main()
