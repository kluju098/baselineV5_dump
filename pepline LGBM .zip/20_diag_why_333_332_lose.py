﻿import os,sys,json
import numpy as np
import pandas as pd
ROOT=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
IN_DIR=os.path.join(ROOT,"LGBM","09","out")
IN18=os.path.join(ROOT,"LGBM","18","out")
OUT_DIR=os.path.join(ROOT,"LGBM","20","out")
os.makedirs(OUT_DIR,exist_ok=True)
os.environ["OMP_NUM_THREADS"]="2"
os.environ["OPENBLAS_NUM_THREADS"]="2"
os.environ["MKL_NUM_THREADS"]="2"
os.environ["VECLIB_MAXIMUM_THREADS"]="2"
os.environ["NUMEXPR_NUM_THREADS"]="2"
LOT=0.01
BASELINE_OLD=10
TREES=800
NMIN_TRAIN=80
STREAMS=["333_mid","332_mid"]
import lightgbm as lgb
def make_X(z):
 state=z["state_feats"].astype(np.float32)
 ctxc=z["ctx_cont"].astype(np.float32)
 ctxk=z["ctx_cat"]
 hour=ctxk[:,0].astype(np.int16)
 dow=ctxk[:,1].astype(np.int16)
 sess=ctxk[:,2].astype(np.int16)
 X=np.concatenate([state,ctxc,np.stack([hour.astype(np.float32),dow.astype(np.float32),sess.astype(np.float32)],axis=1)],axis=1).astype(np.float32)
 return X
def corr(a,b):
 a=a.astype(np.float64); b=b.astype(np.float64)
 if a.size<3: return 0.0
 am=a-a.mean(); bm=b-b.mean()
 da=np.sqrt(np.mean(am*am)); db=np.sqrt(np.mean(bm*bm))
 if da<1e-12 or db<1e-12: return 0.0
 return float(np.mean(am*bm)/(da*db))
def main():
 bp=os.path.join(IN18,"best_params_per_stream.csv")
 if not os.path.exists(bp): raise RuntimeError(("MISSING",bp))
 best=pd.read_csv(bp).set_index("stream")
 print("ROOT",ROOT)
 print("IN_DIR",IN_DIR)
 print("OUT_DIR",OUT_DIR)
 rows=[]
 for stream in STREAMS:
  path=os.path.join(IN_DIR,f"datasetK_{stream}.npz")
  if not os.path.exists(path): raise RuntimeError(("MISSING_DATASETK",stream,path))
  z=np.load(path,allow_pickle=True)
  keep=z["keep"].astype(np.uint8)
  acts=z["pnl_atr_actions"].astype(np.float32)
  actions_old=z["actions_old"].astype(np.int16)
  ctxk=z["ctx_cat"]
  month=ctxk[:,3].astype(np.int32)
  K=acts.shape[1]
  w=np.where(actions_old==BASELINE_OLD)[0]
  if w.size==0: raise RuntimeError(("BASELINE_NOT_IN_K",stream,int(BASELINE_OLD)))
  abase=int(w[0])
  X=make_X(z)
  cat_idx=[X.shape[1]-3,X.shape[1]-2,X.shape[1]-1, X.shape[1]]
  params={"objective":"huber","alpha":0.9,"learning_rate":0.05,"num_leaves":63,"min_data_in_leaf":50,"feature_fraction":0.9,"bagging_fraction":0.9,"bagging_freq":1,"max_bin":255,"num_threads":2,"verbosity":-1,"seed":1337}
  q=float(best.loc[stream,"q"]); tau_min=float(best.loc[stream,"tau_min"]); budget=float(best.loc[stream,"budget"])
  m_sorted=np.unique(month); m_sorted.sort()
  per=int(np.ceil(float(TREES)/max(1,int(m_sorted.size))))
  booster=None
  rem=int(TREES)
  margins_hist=[]
  outm=[]
  for mi,m in enumerate(m_sorted.tolist()):
   mm=(month==m)
   dec_idx=np.flatnonzero(mm & (keep==1))
   if booster is None or dec_idx.size==0:
    outm.append({"stream":stream,"month":int(m),"n_dec":int(dec_idx.size),"switch_rate":0.0,"mean_margin":0.0,"mean_delta_atr_sw":0.0,"pct_delta_pos_sw":0.0,"corr_margin_delta":0.0,"top_actions":""})
   else:
    Xmm=X[dec_idx]
    Q=np.empty((dec_idx.size,K),np.float32)
    for a in range(K):
     a_col=np.full((dec_idx.size,1),float(a),np.float32)
     Xa=np.concatenate([Xmm,a_col],axis=1)
     Q[:,a]=booster.predict(Xa,num_iteration=booster.current_iteration()).astype(np.float32)
    q_base=Q[:,abase]
    best_a=np.argmax(Q,axis=1).astype(np.int16)
    q_best=Q[np.arange(best_a.size),best_a.astype(np.int64)]
    margin=(q_best-q_base).astype(np.float32)
    order=np.argsort(-margin)
    hist=np.concatenate(margins_hist).astype(np.float32) if len(margins_hist) else None
    thr=float(np.quantile(hist,q)) if hist is not None and hist.size else 1e9
    eff=max(thr,float(tau_min)) if hist is not None and hist.size else float(tau_min)
    elig=(margin>=eff)
    k=int(np.floor(float(budget)*float(best_a.size)))
    if k<=0:
     pred=np.full(best_a.size,abase,np.int16)
    else:
     pick=order[:k]
     choose=np.zeros(best_a.size,np.bool_)
     choose[pick]=True
     choose &= elig
     pred=np.full(best_a.size,abase,np.int16)
     pred[choose]=best_a[choose]
    base_atr=acts[dec_idx,abase].astype(np.float32)
    pred_atr=acts[dec_idx,pred.astype(np.int64)].astype(np.float32)
    delta=(pred_atr-base_atr).astype(np.float32)
    sw=(pred!=abase)
    sw_rate=float(np.mean(sw)) if sw.size else 0.0
    mean_m=float(np.mean(margin)) if margin.size else 0.0
    if np.any(sw):
     dsw=delta[sw]
     mean_d=float(np.mean(dsw)) if dsw.size else 0.0
     pctp=float(np.mean(dsw>0)) if dsw.size else 0.0
     cm=corr(margin[sw],dsw)
    else:
     mean_d=0.0; pctp=0.0; cm=0.0
    vc=np.bincount(pred.astype(np.int64),minlength=K)
    top=np.argsort(-vc)[:5]
    top_s=",".join([f"{int(actions_old[i])}:{int(vc[i])}" for i in top if vc[i]>0])
    outm.append({"stream":stream,"month":int(m),"n_dec":int(dec_idx.size),"switch_rate":sw_rate,"mean_margin":mean_m,"mean_delta_atr_sw":mean_d,"pct_delta_pos_sw":pctp,"corr_margin_delta":cm,"top_actions":top_s})
    margins_hist.append(margin.copy())
   tr_months=m_sorted[:mi+1]
   tr_idx=np.flatnonzero(np.isin(month,tr_months) & (keep==1))
   if rem>0 and tr_idx.size>=NMIN_TRAIN:
    Xr=np.repeat(X[tr_idx],K,axis=0)
    a=np.tile(np.arange(K,dtype=np.int16),tr_idx.size).astype(np.float32).reshape(-1,1)
    y=acts[tr_idx].reshape(-1).astype(np.float32)
    base_rep=np.repeat(acts[tr_idx,abase],K).astype(np.float32)
    delta_tr=(y-base_rep).astype(np.float32)
    wgt=np.clip(np.maximum(delta_tr,0.0),0.0,2.0)+0.02
    Xa=np.concatenate([Xr,a],axis=1).astype(np.float32)
    add=min(per,rem)
    dtrain=lgb.Dataset(Xa,label=delta_tr,weight=wgt,categorical_feature=cat_idx,free_raw_data=True)
    booster=lgb.train(params,dtrain,num_boost_round=int(add),init_model=booster,keep_training_booster=True)
    rem-=int(add)
  df=pd.DataFrame(outm)
  df.to_csv(os.path.join(OUT_DIR,f"diag_{stream}.csv"),index=False)
  print("[20] STREAM",stream,"BEST(q,tau,budget)",q,tau_min,budget)
  print(df.to_string(index=False))
  rows.append({"stream":stream,"months":int(df.shape[0]),"mean_switch_rate":float(df["switch_rate"].mean()),"mean_delta_atr_sw":float(df.loc[df["switch_rate"]>0,"mean_delta_atr_sw"].mean() if np.any(df["switch_rate"]>0) else 0.0),"mean_corr_margin_delta":float(df.loc[df["switch_rate"]>0,"corr_margin_delta"].mean() if np.any(df["switch_rate"]>0) else 0.0)})
 summ=pd.DataFrame(rows)
 summ.to_csv(os.path.join(OUT_DIR,"diag_summary.csv"),index=False)
 print("[20] SUMMARY")
 print(summ.to_string(index=False))
 print("[20] FILES diag_333_mid.csv diag_332_mid.csv diag_summary.csv")
if __name__=="__main__":
 main()
