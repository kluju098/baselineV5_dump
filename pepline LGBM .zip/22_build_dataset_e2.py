﻿import os,sys,json
import numpy as np
import pandas as pd
STREAMS=["222_high","222_mid","223_mid","332_high","332_mid","333_mid"]
def must(z,keys,stream):
 miss=[k for k in keys if k not in z.files]
 if miss: raise RuntimeError(("NPZ_MISSING_KEYS",stream,miss,"have",list(z.files)))
 return [z[k] for k in keys]
def main(root):
 in_dir=os.path.join(root,"LGBM","09","out")
 out_dir=os.path.join(root,"LGBM","22","out")
 os.makedirs(out_dir,exist_ok=True)
 E1_ABS=float(os.environ.get("E1_ABS","0.05"))
 BEST_THR=float(os.environ.get("BEST_THR","0.3"))
 RETR_THR=float(os.environ.get("RETR_THR","0.1"))
 W=int(os.environ.get("W","20"))
 print("ROOT",root)
 print("IN_DIR",in_dir)
 print("OUT_DIR",out_dir)
 print("E1_ABS",E1_ABS,"BEST_THR",BEST_THR,"RETR_THR",RETR_THR,"W",W)
 rows=[]
 per_stream=[]
 for stream in STREAMS:
  p=os.path.join(in_dir,f"datasetK_{stream}.npz")
  if not os.path.exists(p):
   print("MISSING_NPZ",stream,p); continue
  z=np.load(p,allow_pickle=False)
  keep,y,base_atr,bestK_atr,best32_atr,pnlA,state,ctx_cont,ctx_cat,actions_old = must(
   z,
   ["keep","y","base_atr","bestK_atr","best32_atr","pnl_atr_actions","state_feats","ctx_cont","ctx_cat","actions_old"],
   stream
  )
  keep=keep.astype(np.uint8,copy=False)
  y=y.astype(np.int32,copy=False)
  base_atr=base_atr.astype(np.float32,copy=False)
  bestK_atr=bestK_atr.astype(np.float32,copy=False)
  best32_atr=best32_atr.astype(np.float32,copy=False)
  pnlA=pnlA.astype(np.float32,copy=False)
  state=state.astype(np.float32,copy=False)
  ctx_cont=ctx_cont.astype(np.float32,copy=False)
  ctx_cat=ctx_cat.astype(np.int32,copy=False)
  actions_old=actions_old.astype(np.int32,copy=False)
  n=int(keep.shape[0])
  K=int(pnlA.shape[1])
  assert state.shape[0]==n and ctx_cont.shape[0]==n and ctx_cat.shape[0]==n and pnlA.shape[0]==n
  assert actions_old.shape[0]==K
  gain=(bestK_atr-base_atr).astype(np.float32,copy=False)
  y_e2=(gain>=BEST_THR).astype(np.int8,copy=False)
  mask=keep.astype(bool)
  n_keep=int(mask.sum())
  if n_keep==0:
   print("STREAM",stream,"n",n,"keep",0,"SKIP_EMPTY_KEEP")
   continue
  hour=ctx_cat[:,0]
  dow=ctx_cat[:,1]
  session_id=ctx_cat[:,2]
  month_id=ctx_cat[:,3]
  X=np.concatenate([state,ctx_cont],axis=1).astype(np.float32,copy=False)
  X_cat=ctx_cat.astype(np.int32,copy=False)
  out_npz=os.path.join(out_dir,f"datasetE2_{stream}.npz")
  np.savez_compressed(
   out_npz,
   keep=keep,
   y_e2=y_e2,
   gain_atr=gain,
   base_atr=base_atr,
   bestK_atr=bestK_atr,
   best32_atr=best32_atr,
   y_bestK=y,
   pnl_atr_actions=pnlA,
   actions_old=actions_old,
   X=X,
   X_cat=X_cat,
   meta=np.array([E1_ABS,BEST_THR,RETR_THR,float(W),float(K)],dtype=np.float32)
  )
  base_usd=float(np.sum(base_atr[mask]))
  oracleK_usd=float(np.sum(bestK_atr[mask]))
  uplift_usd=float(np.sum(gain[mask]))
  on_rate=float(np.mean(y_e2[mask]))
  mean_gain=float(np.mean(gain[mask]))
  p_ge_01=float(np.mean(gain[mask]>=0.10))
  p_ge_thr=float(np.mean(gain[mask]>=BEST_THR))
  print("STREAM",stream,"n",n,"keep",n_keep,"K",K,
        "BASE_ATR_SUM",f"{base_usd:.6f}",
        "ORACLEK_ATR_SUM",f"{oracleK_usd:.6f}",
        "UPLIFT_ATR_SUM",f"{uplift_usd:.6f}",
        "ON_RATE",f"{on_rate:.6f}",
        "mean_gain",f"{mean_gain:.6f}",
        "pct>=0.10",f"{p_ge_01:.6f}",
        "pct>=thr",f"{p_ge_thr:.6f}",
        "OUT",os.path.basename(out_npz))
  per_stream.append([stream,n_keep,K,base_usd,oracleK_usd,uplift_usd,on_rate,mean_gain,p_ge_01,p_ge_thr])
  dfm=pd.DataFrame({"month":month_id[mask].astype(np.int32),
                    "gain":gain[mask].astype(np.float32),
                    "y_e2":y_e2[mask].astype(np.int8)})
  g=dfm.groupby("month",as_index=False).agg(
   n=("gain","size"),
   on_rate=("y_e2","mean"),
   mean_gain=("gain","mean"),
   pct_ge_0_10=("gain",lambda x: float(np.mean(np.asarray(x)>=0.10))),
   pct_ge_thr=("gain",lambda x: float(np.mean(np.asarray(x)>=BEST_THR))),
   uplift_atr=("gain","sum")
  ).sort_values("month")
  g["stream"]=stream
  g.to_csv(os.path.join(out_dir,f"monthly_e2_{stream}.csv"),index=False)
  rows.append(g)
 if per_stream:
  cols=["stream","keep_n","K","base_atr_sum","oracleK_atr_sum","uplift_atr_sum","on_rate","mean_gain","pct_ge_0_10","pct_ge_thr"]
  d=pd.DataFrame(per_stream,columns=cols).sort_values("uplift_atr_sum",ascending=False)
  d.to_csv(os.path.join(out_dir,"summary_e2_streams.csv"),index=False)
  base_total=float(d["base_atr_sum"].sum())
  oracle_total=float(d["oracleK_atr_sum"].sum())
  uplift_total=float(d["uplift_atr_sum"].sum())
  on_rate_avg=float(np.mean(d["on_rate"].values))
  print("[22] TOTAL_ATR BASE",f"{base_total:.6f}","MODEL_E2_SWITCHABLE_UPLIFT",f"{uplift_total:.6f}",
        "ORACLEK",f"{oracle_total:.6f}","avg_on_rate",f"{on_rate_avg:.6f}")
  meta={"E1_ABS":E1_ABS,"BEST_THR":BEST_THR,"RETR_THR":RETR_THR,"W":W}
  with open(os.path.join(out_dir,"meta.json"),"w",encoding="utf-8") as f: json.dump(meta,f,indent=2)
  print("[22] FILES","summary_e2_streams.csv meta.json monthly_e2_<stream>.csv datasetE2_<stream>.npz")
 else:
  print("[22] NO_STREAMS_BUILT")
if __name__=="__main__":
 root=os.environ.get("ROOT")
 if not root: raise RuntimeError("SET_ROOT_ENV")
 main(root)
