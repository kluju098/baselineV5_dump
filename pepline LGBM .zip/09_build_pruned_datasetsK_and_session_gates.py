﻿import os,sys,json
import numpy as np
import pandas as pd
ROOT=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
IN_DIR=os.path.join(ROOT,"LGBM","05","out")
PRUNE_JSON=os.path.join(ROOT,"LGBM","08","out","actions_pruned.json")
OUT_DIR=os.path.join(ROOT,"LGBM","09","out")
os.makedirs(OUT_DIR,exist_ok=True)
os.environ["OMP_NUM_THREADS"]="2"
os.environ["OPENBLAS_NUM_THREADS"]="2"
os.environ["MKL_NUM_THREADS"]="2"
os.environ["VECLIB_MAXIMUM_THREADS"]="2"
os.environ["NUMEXPR_NUM_THREADS"]="2"
LOT=0.01
BASELINE_ACTION_IDX=10
MIN_SESS_COUNT=8
def fmt(x):
 if isinstance(x,(int,np.integer)): return str(int(x))
 if isinstance(x,(float,np.floating)):
  v=float(x)
  if abs(v)>=1000: return f"{v:,.0f}".replace(","," ")
  if abs(v)>=100: return f"{v:.1f}"
  if abs(v)>=10: return f"{v:.2f}"
  return f"{v:.3f}"
 return str(x)
def usd(pnl_atr,atr):
 return pnl_atr.astype(np.float64)*atr.astype(np.float64)*100.0*LOT
def decode_action(idx):
 i=int(idx)
 be_mode=0 if i<16 else 1
 j=i if i<16 else i-16
 ts_mult=[0.5,0.75,1.0,1.25][j//4]
 td_mult=[0.5,0.75,1.0,1.25][j%4]
 return float(ts_mult),float(td_mult),int(be_mode)
def main():
 if not os.path.exists(PRUNE_JSON): raise RuntimeError(("PRUNE_JSON_NOT_FOUND",PRUNE_JSON))
 with open(PRUNE_JSON,"r",encoding="utf-8") as f: pm=json.load(f)
 files=sorted([f for f in os.listdir(IN_DIR) if f.startswith("dataset32_full_") and f.endswith(".npz")])
 if not files: raise RuntimeError(("NO_DATASET32_FULL",IN_DIR))
 print("ROOT",ROOT)
 print("IN_DIR",IN_DIR)
 print("OUT_DIR",OUT_DIR)
 print("BASELINE_ACTION_IDX",BASELINE_ACTION_IDX,"MIN_SESS_COUNT",MIN_SESS_COUNT)
 sum_rows=[]
 gates={}
 for fn in files:
  stream=fn[len("dataset32_full_"):-4]
  z=np.load(os.path.join(IN_DIR,fn),allow_pickle=True)
  keep=z["keep"].astype(np.uint8)
  base=z["base_atr"].astype(np.float32)
  best32=z["best_atr"].astype(np.float32)
  acts=z["pnl_atr_actions"].astype(np.float32)
  state=z["state_feats"].astype(np.float32)
  ctxc=z["ctx_cont"].astype(np.float32)
  ctxk=z["ctx_cat"]
  sess=ctxk[:,2].astype(np.int16)
  month=ctxk[:,3].astype(np.int32)
  atr=ctxc[:,3].astype(np.float32)
  n=int(base.size)
  km=(keep==1)
  nk=int(km.sum())
  if stream not in pm: raise RuntimeError(("MISSING_PRUNE_FOR_STREAM",stream))
  A=list(pm[stream]["actions"])
  if BASELINE_ACTION_IDX not in A: A.append(BASELINE_ACTION_IDX)
  A=sorted(set(int(x) for x in A))
  Aidx=np.array(A,dtype=np.int16)
  actsA=acts[:,Aidx.astype(np.int64)].astype(np.float32)
  yA=np.argmax(actsA,axis=1).astype(np.int16)
  bestA=np.max(actsA,axis=1).astype(np.float32)
  a0=0
  a0i=int(np.where(Aidx==a0)[0][0]) if a0 in A else -1
  if a0i>=0:
   p0=actsA[:,a0i]
  else:
   p0=acts[:,a0]
  base_usd=float(np.sum(usd(base,atr)))
  best32_usd=float(np.sum(usd(best32,atr)))
  bestA_usd=float(np.sum(usd(bestA,atr)))
  a0_usd=float(np.sum(usd(p0,atr)))
  sum_rows.append({"stream":stream,"n":n,"keep":nk,"K":int(len(Aidx)),"base_usd":base_usd,"always_action0_usd":a0_usd,"oracleK_usd":bestA_usd,"oracle32_usd":best32_usd,"loss_vs_32_usd":bestA_usd-best32_usd})
  gc={}
  for s in [0,1,2]:
   ms=(sess==s)&km
   if not np.any(ms):
    gc[str(s)]={"allowed_new":[],"counts":[]}
    continue
   yy=yA[ms]
   cnt=np.bincount(yy,minlength=int(len(Aidx))).astype(np.int64)
   allowed=np.flatnonzero(cnt>=MIN_SESS_COUNT).astype(np.int16).tolist()
   if int(np.argmax(cnt)) not in allowed: allowed.append(int(np.argmax(cnt)))
   if a0 in A and a0i not in allowed: allowed.append(int(a0i))
   allowed=sorted(set(int(x) for x in allowed))
   gc[str(s)]={"allowed_new":allowed,"counts":cnt.tolist()}
  gates[stream]={"A_old":A,"A_old_decode":[{"old":int(Aidx[i]),"new":int(i), "ts_mult":decode_action(int(Aidx[i]))[0], "td_mult":decode_action(int(Aidx[i]))[1], "be_mode":decode_action(int(Aidx[i]))[2]} for i in range(int(len(Aidx)))],"session_gates":gc}
  np.savez_compressed(os.path.join(OUT_DIR,f"datasetK_{stream}.npz"),keep=keep.astype(np.uint8),y=yA.astype(np.int16),base_atr=base.astype(np.float32),bestK_atr=bestA.astype(np.float32),best32_atr=best32.astype(np.float32),pnl_atr_actions=actsA.astype(np.float32),state_feats=state.astype(np.float32),ctx_cont=ctxc.astype(np.float32),ctx_cat=ctxk,actions_old=Aidx.astype(np.int16))
  print("STREAM",stream,"n",n,"keep",nk,"K",int(len(Aidx)),"BASE",fmt(base_usd),"A0",fmt(a0_usd),"ORACLE_K",fmt(bestA_usd),"ORACLE_32",fmt(best32_usd),"K_minus_32",fmt(bestA_usd-best32_usd))
 sumdf=pd.DataFrame(sum_rows).sort_values("oracleK_usd",ascending=False)
 sumdf.to_csv(os.path.join(OUT_DIR,"summary_pruned_streams.csv"),index=False)
 with open(os.path.join(OUT_DIR,"gates_actionsK.json"),"w",encoding="utf-8") as f: json.dump(gates,f,ensure_ascii=False)
 print("[09] SUMMARY_PRUNED_STREAMS")
 print(sumdf.to_string(index=False))
 print("[09] FILES summary_pruned_streams.csv datasetK_*.npz gates_actionsK.json")
if __name__=="__main__":
 main()
