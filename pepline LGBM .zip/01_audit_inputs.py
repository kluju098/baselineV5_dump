﻿import os,json,sys
import numpy as np
import pandas as pd
ROOT=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
OUT_DIR=os.path.join(ROOT,"LGBM","01","out")
os.makedirs(OUT_DIR,exist_ok=True)
DS_LIST=["222","223","332","333"]
PNL_FILE="pnl_net_atr_T599.f32"
TRADES_FILE="trades.parquet"
META_FILE="meta.json"
SEC0_FILE="sec0.npz"
REQ_COLS=["trade_id","hour_utc","rsi","mfi","adx","atr","cost_atr","entry_ts_ms"]
def pth(*a): return os.path.join(*a)
def load_meta(path):
 try:
  with open(path,"r",encoding="utf-8") as f: return json.load(f)
 except Exception as e:
  return {"_err":str(e)}
def safe_npz_info(path):
 try:
  z=np.load(path,allow_pickle=False)
  keys=list(z.files)
  info={}
  for k in keys[:12]:
   v=z[k]
   info[k]={"dtype":str(v.dtype),"shape":tuple(int(x) for x in v.shape)}
  return {"keys":keys,"preview":info}
 except Exception as e:
  return {"_err":str(e)}
def df_profile(df,cols):
 out={}
 n=len(df)
 out["n"]=int(n)
 for c in cols:
  if c not in df.columns:
   out[c]={"missing_col":True}
   continue
  s=df[c]
  nn=int(s.isna().sum())
  d={"na":nn}
  if pd.api.types.is_numeric_dtype(s):
   x=s.to_numpy()
   if x.size:
    if np.issubdtype(x.dtype,np.number):
     with np.errstate(all="ignore"):
      d["min"]=float(np.nanmin(x)) if np.isfinite(np.nanmin(x)) else None
      d["max"]=float(np.nanmax(x)) if np.isfinite(np.nanmax(x)) else None
      q=np.nanpercentile(x,[1,5,25,50,75,95,99]).astype(np.float64)
      d["p01"]=float(q[0]); d["p05"]=float(q[1]); d["p25"]=float(q[2]); d["p50"]=float(q[3]); d["p75"]=float(q[4]); d["p95"]=float(q[5]); d["p99"]=float(q[6])
  else:
   d["nuniq"]=int(s.nunique(dropna=True))
  out[c]=d
 return out
def pnl_check(pnl_path,nrows):
 ok=False
 size=os.path.getsize(pnl_path) if os.path.exists(pnl_path) else -1
 exp=int(nrows)*600*4
 ok=(size==exp)
 return {"exists":bool(os.path.exists(pnl_path)),"bytes":int(size),"expected_bytes":int(exp),"ok":bool(ok)}
def head_preview(df):
 keep=[c for c in ["trade_id","hour_utc","rsi","mfi","adx","atr","cost_atr","entry_ts_ms"] if c in df.columns]
 return df[keep].head(3).to_dict(orient="records")
def main():
 print("AUDIT_ROOT",ROOT)
 found=[]
 missing=[]
 for ds in DS_LIST:
  ddir=pth(ROOT,ds)
  if os.path.isdir(ddir): found.append(ds)
  else: missing.append(ds)
 print("DS_FOUND",",".join(found))
 if missing: raise RuntimeError(("MISSING_DS_DIRS",missing))
 rows=[]
 full={}
 for ds in DS_LIST:
  ddir=pth(ROOT,ds)
  tp=pth(ddir,TRADES_FILE)
  pp=pth(ddir,PNL_FILE)
  mp=pth(ddir,META_FILE)
  sp=pth(ddir,SEC0_FILE)
  if not os.path.exists(tp): raise RuntimeError(("TRADES_NOT_FOUND",ds,tp))
  df=pd.read_parquet(tp)
  n=len(df)
  cols=list(df.columns)
  miss=[c for c in REQ_COLS if c not in cols]
  meta=load_meta(mp) if os.path.exists(mp) else {"_err":"NO_META_JSON"}
  sec0=safe_npz_info(sp) if os.path.exists(sp) else {"_err":"NO_SEC0_NPZ"}
  pc=pnl_check(pp,n)
  prof=df_profile(df,REQ_COLS)
  one={
   "ds":ds,
   "n":int(n),
   "cols":cols,
   "missing_required":miss,
   "pnl":pc,
   "meta":{k:meta.get(k) for k in list(meta.keys())[:20]} if isinstance(meta,dict) else {"_err":"META_NOT_DICT"},
   "sec0":sec0
  }
  full[ds]=one
  rows.append({
   "ds":ds,
   "n":int(n),
   "n_cols":int(len(cols)),
   "missing_required":(";".join(miss) if miss else ""),
   "pnl_ok":int(pc["ok"]),
   "pnl_bytes":int(pc["bytes"]),
   "expected_bytes":int(pc["expected_bytes"])
  })
  print("DS",ds,"n",n,"cols",len(cols),"pnl_ok",int(pc["ok"]),"miss_req",len(miss))
  if miss: print("  MISSING_COLS",",".join(miss))
  if not pc["ok"]: print("  PNL_BYTES",pc["bytes"],"EXPECTED",pc["expected_bytes"])
  pv=head_preview(df)
  print("  HEAD3",json.dumps(pv,ensure_ascii=False))
 prof_out={}
 for ds in DS_LIST:
  df=pd.read_parquet(pth(ROOT,ds,TRADES_FILE),columns=[c for c in REQ_COLS if c!="trade_id"])
  prof_out[ds]=df_profile(df,[c for c in REQ_COLS if c!="trade_id"])
 with open(pth(OUT_DIR,"audit_full.json"),"w",encoding="utf-8") as f:
  json.dump(full,f,ensure_ascii=False)
 with open(pth(OUT_DIR,"audit_profile.json"),"w",encoding="utf-8") as f:
  json.dump(prof_out,f,ensure_ascii=False)
 pd.DataFrame(rows).to_csv(pth(OUT_DIR,"audit_table.csv"),index=False)
 ok_all=True
 for ds in DS_LIST:
  if full[ds]["missing_required"]: ok_all=False
  if not full[ds]["pnl"]["ok"]: ok_all=False
 if not ok_all: raise RuntimeError(("AUDIT_FAIL","See audit_full.json / audit_table.csv"))
 print("AUDIT_PASS",",".join(DS_LIST))
 print("OUT_DIR",OUT_DIR)
 print("FILES","audit_table.csv audit_profile.json audit_full.json")
if __name__=="__main__":
 main()
