﻿import os,sys
import numpy as np
STREAMS=["222_high","222_mid","223_mid","332_high","332_mid","333_mid"]
def sshape(x):
 try: return "x".join(str(i) for i in x.shape)
 except: return "?"
def main(root):
 in_dir=os.path.join(root,"LGBM","09","out")
 print("ROOT",root)
 print("IN_DIR",in_dir)
 ok=0
 for stream in STREAMS:
  p=os.path.join(in_dir,f"datasetK_{stream}.npz")
  if not os.path.exists(p):
   print("NPZ_MISSING",stream,p)
   continue
  z=np.load(p,allow_pickle=False)
  keys=list(z.files)
  print("NPZ",stream,"FILE",os.path.basename(p),"KEYS",keys)
  for k in keys:
   a=z[k]
   dt=str(a.dtype) if hasattr(a,"dtype") else "?"
   sh=sshape(a)
   mx=""
   if hasattr(a,"ndim") and a.ndim==1 and a.size>0 and a.dtype.kind in "if":
    mx=f" min={float(np.min(a)):.6g} max={float(np.max(a)):.6g}"
   if hasattr(a,"ndim") and a.ndim==2 and a.shape[0]>0 and a.shape[1]>0 and a.dtype.kind in "if":
    r0=a[0,:min(6,a.shape[1])].astype(np.float64,copy=False)
    mx=f" r0={np.array2string(r0,precision=6,separator=',')}"
   print(" ",k,"dtype",dt,"shape",sh+mx)
  ok+=1
 print("DONE","found",ok,"of",len(STREAMS))
if __name__=="__main__":
 root=os.environ.get("ROOT")
 if not root: raise RuntimeError("SET_ROOT_ENV")
 main(root)
