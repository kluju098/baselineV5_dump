﻿import os,sys,time,json
import numpy as np
import pandas as pd
ROOT=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
IN_DIR=os.path.join(ROOT,"LGBM","05","out")
OUT_DIR=os.path.join(ROOT,"LGBM","07","out")
os.makedirs(OUT_DIR,exist_ok=True)
os.environ["OMP_NUM_THREADS"]="2"
os.environ["OPENBLAS_NUM_THREADS"]="2"
os.environ["MKL_NUM_THREADS"]="2"
os.environ["VECLIB_MAXIMUM_THREADS"]="2"
os.environ["NUMEXPR_NUM_THREADS"]="2"
USDPLN=3.54
LOT=0.01
BASELINE_ACTION_IDX=10
import lightgbm as lgb
def fmt(v):
 if isinstance(v,(int,np.integer)): return str(int(v))
 if isinstance(v,(float,np.floating)):
  x=float(v)
  if abs(x)>=1000: return f"{x:,.0f}".replace(","," ")
  if abs(x)>=100: return f"{x:.1f}"
  if abs(x)>=10: return f"{x:.2f}"
  return f"{x:.3f}"
 return str(v)
def usd(pnl_atr,atr):
 return pnl_atr.astype(np.float64)*atr.astype(np.float64)*100.0*LOT
def train_one(stream,path,trees_total=1000,num_threads=2):
 z=np.load(path,allow_pickle=True)
 keep=z["keep"].astype(np.uint8)
 y=z["y"].astype(np.uint8)
 base_atr=z["base_atr"].astype(np.float32)
 best_atr=z["best_atr"].astype(np.float32)
 acts=z["pnl_atr_actions"].astype(np.float32)
 state=z["state_feats"].astype(np.float32)
 ctxc=z["ctx_cont"].astype(np.float32)
 ctxk=z["ctx_cat"]
 hour=ctxk[:,0].astype(np.int16)
 dow=ctxk[:,1].astype(np.int16)
 sess=ctxk[:,2].astype(np.int16)
 month=ctxk[:,3].astype(np.int32)
 atr=ctxc[:,3].astype(np.float32)
 n=int(base_atr.size)
 n_dec=int(np.sum(keep))
 sanity=float(np.max(np.abs(base_atr-acts[:,BASELINE_ACTION_IDX])))
 cols_state=[str(x) for x in z["feat_state"].tolist()]
 cols_ctxc=[str(x) for x in z["feat_ctx_cont"].tolist()]
 cols=cols_state+cols_ctxc+["hour_waw","dow_waw","session_id"]
 X=np.concatenate([state,ctxc,np.stack([hour.astype(np.float32),dow.astype(np.float32),sess.astype(np.float32)],axis=1)],axis=1).astype(np.float32)
 df=pd.DataFrame(X,columns=cols)
 df["hour_waw"]=df["hour_waw"].astype(np.int16).astype("category")
 df["dow_waw"]=df["dow_waw"].astype(np.int16).astype("category")
 df["session_id"]=df["session_id"].astype(np.int16).astype("category")
 m_sorted=np.unique(month); m_sorted.sort()
 M=int(m_sorted.size)
 per=int(np.ceil(float(trees_total)/float(M))) if M>0 else trees_total
 remaining=int(trees_total)
 booster=None
 pred_act=np.full(n,BASELINE_ACTION_IDX,np.int16)
 rows=[]
 t0=time.perf_counter()
 params={"objective":"multiclass","num_class":32,"learning_rate":0.07,"num_leaves":63,"min_data_in_leaf":30,"feature_fraction":0.9,"bagging_fraction":0.9,"bagging_freq":1,"max_bin":255,"num_threads":int(num_threads),"verbosity":-1,"seed":1337}
 for m in m_sorted.tolist():
  mm=(month==m)
  pred_idx=np.flatnonzero(mm & (keep==1))
  if booster is not None and pred_idx.size>0:
   p=booster.predict(df.iloc[pred_idx][cols],num_iteration=booster.current_iteration())
   pred_act[pred_idx]=np.argmax(p,axis=1).astype(np.int16)
  model_atr=acts[mm,pred_act[mm].astype(np.int64)]
  b_atr=base_atr[mm]; o_atr=best_atr[mm]; au=atr[mm]
  base_usd=float(np.sum(usd(b_atr,au)))
  oracle_usd=float(np.sum(usd(o_atr,au)))
  model_usd=float(np.sum(usd(model_atr,au)))
  rows.append({"month":int(m),"n":int(np.sum(mm)),"n_pred":int(pred_idx.size),"base_usd":base_usd,"model_usd":model_usd,"oracle_usd":oracle_usd,"uplift_usd":model_usd-base_usd,"model_oracle_pct":(model_usd/oracle_usd if abs(oracle_usd)>1e-12 else 0.0)})
  tr_idx=np.flatnonzero(mm & (keep==1))
  if remaining>0 and tr_idx.size>0:
   add=min(per,remaining)
   w=(best_atr[tr_idx]-base_atr[tr_idx]).astype(np.float32)
   w=np.clip(w,0.0,2.0)
   dtrain=lgb.Dataset(df.iloc[tr_idx][cols],label=y[tr_idx].astype(np.int32),weight=w,free_raw_data=True)
   booster=lgb.train(params,dtrain,num_boost_round=int(add),init_model=booster,keep_training_booster=True)
   remaining-=int(add)
 rep=pd.DataFrame(rows)
 rep.to_csv(os.path.join(OUT_DIR,f"monthly_{stream}.csv"),index=False)
 used=int(trees_total-remaining)
 model_all=float(np.sum(usd(acts[np.arange(n),pred_act.astype(np.int64)],atr)))
 base_all=float(np.sum(usd(base_atr,atr)))
 oracle_all=float(np.sum(usd(best_atr,atr)))
 t1=time.perf_counter()
 if booster is not None:
  booster.save_model(os.path.join(OUT_DIR,f"model_{stream}.txt"))
 out={"stream":stream,"n":n,"n_decision":n_dec,"trees_used":used,"train_sec":float(t1-t0),"base_usd":base_all,"model_usd":model_all,"oracle_usd":oracle_all,"uplift_usd":model_all-base_all,"model_oracle_pct":(model_all/oracle_all if abs(oracle_all)>1e-12 else 0.0),"sanity_base_vs_action10_maxabs":sanity}
 return out,rep
def main():
 files=sorted([f for f in os.listdir(IN_DIR) if f.startswith("dataset32_full_") and f.endswith(".npz")])
 if not files: raise RuntimeError(("NO_DATASET32_FULL",IN_DIR))
 meta={"threads":2,"trees_total_per_stream":1000,"baseline_action_idx":BASELINE_ACTION_IDX,"features":"state_feats(12)+ctx_cont(5)+hour/dow/session","no_t_feature":True,"walk_forward":"predict month m with model from <m then train on m","fix":"use iloc with np.flatnonzero and skip empty"}
 with open(os.path.join(OUT_DIR,"train_meta.json"),"w",encoding="utf-8") as f: json.dump(meta,f,ensure_ascii=False)
 print("ROOT",ROOT)
 print("IN_DIR",IN_DIR)
 print("OUT_DIR",OUT_DIR)
 print("THREADS",2,"TREES_PER_STREAM",1000,"BASELINE_ACTION_IDX",BASELINE_ACTION_IDX)
 allsum=[]
 for fn in files:
  stream=fn[len("dataset32_full_"):-4]
  path=os.path.join(IN_DIR,fn)
  s,rep=train_one(stream,path,trees_total=1000,num_threads=2)
  allsum.append(s)
  print("STREAM",stream,"n",s["n"],"dec",s["n_decision"],"trees",s["trees_used"],"train_sec",fmt(s["train_sec"]), "BASE",fmt(s["base_usd"]),"MODEL",fmt(s["model_usd"]),"ORACLE",fmt(s["oracle_usd"]),"uplift",fmt(s["uplift_usd"]),"pct_oracle",fmt(s["model_oracle_pct"]),"sanity",("{:.9f}".format(s["sanity_base_vs_action10_maxabs"])))
 sumdf=pd.DataFrame(allsum).sort_values("uplift_usd",ascending=False)
 sumdf.to_csv(os.path.join(OUT_DIR,"summary_streams.csv"),index=False)
 tot_base=float(sumdf["base_usd"].sum())
 tot_model=float(sumdf["model_usd"].sum())
 tot_oracle=float(sumdf["oracle_usd"].sum())
 print("[07] SUMMARY_STREAMS")
 print(sumdf[["stream","n","n_decision","trees_used","train_sec","base_usd","model_usd","oracle_usd","uplift_usd","model_oracle_pct","sanity_base_vs_action10_maxabs"]].to_string(index=False))
 print("[07] TOTAL","BASE",fmt(tot_base),"MODEL",fmt(tot_model),"ORACLE",fmt(tot_oracle),"uplift",fmt(tot_model-tot_base),"pct_oracle",fmt((tot_model/tot_oracle if abs(tot_oracle)>1e-12 else 0.0)))
 print("[07] FILES summary_streams.csv monthly_*.csv model_*.txt train_meta.json")
if __name__=="__main__":
 main()
