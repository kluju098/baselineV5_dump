﻿import os,sys,time,json
import numpy as np
import pandas as pd
ROOT=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
IN_DIR=os.path.join(ROOT,"LGBM","09","out")
OUT_DIR=os.path.join(ROOT,"LGBM","12","out")
os.makedirs(OUT_DIR,exist_ok=True)
os.environ["OMP_NUM_THREADS"]="2"
os.environ["OPENBLAS_NUM_THREADS"]="2"
os.environ["MKL_NUM_THREADS"]="2"
os.environ["VECLIB_MAXIMUM_THREADS"]="2"
os.environ["NUMEXPR_NUM_THREADS"]="2"
LOT=0.01
BASELINE_OLD=10
TREES=800
NMIN_TRAIN=80
import lightgbm as lgb
def fmt(v):
 if isinstance(v,(int,np.integer)): return str(int(v))
 if isinstance(v,(float,np.floating)):
  x=float(v)
  if abs(x)>=1000: return f"{x:,.0f}".replace(","," ")
  if abs(x)>=100: return f"{x:.1f}"
  if abs(x)>=10: return f"{x:.2f}"
  return f"{x:.3f}"
 return str(v)
def usd(pnl_atr,atr):
 return pnl_atr.astype(np.float64)*atr.astype(np.float64)*100.0*LOT
def build_long(X,acts,mm_idx,K):
 n=mm_idx.size
 Xr=np.repeat(X[mm_idx],K,axis=0)
 a=np.tile(np.arange(K,dtype=np.int16),n)
 y=acts[mm_idx].reshape(-1).astype(np.float32)
 return Xr,a,y
def train_q_stream(stream,z):
 keep=z["keep"].astype(np.uint8)
 base=z["base_atr"].astype(np.float32)
 bestK=z["bestK_atr"].astype(np.float32)
 acts=z["pnl_atr_actions"].astype(np.float32)
 state=z["state_feats"].astype(np.float32)
 ctxc=z["ctx_cont"].astype(np.float32)
 ctxk=z["ctx_cat"]
 actions_old=z["actions_old"].astype(np.int16)
 hour=ctxk[:,0].astype(np.int16)
 dow=ctxk[:,1].astype(np.int16)
 sess=ctxk[:,2].astype(np.int16)
 month=ctxk[:,3].astype(np.int32)
 atr=ctxc[:,3].astype(np.float32)
 n=base.size
 K=acts.shape[1]
 w=np.where(actions_old==BASELINE_OLD)[0]
 if w.size==0: raise RuntimeError(("BASELINE_NOT_IN_K",stream,int(BASELINE_OLD)))
 baseline_new=int(w[0])
 X=np.concatenate([state,ctxc,np.stack([hour.astype(np.float32),dow.astype(np.float32),sess.astype(np.float32)],axis=1)],axis=1).astype(np.float32)
 cat_idx=[X.shape[1]-3,X.shape[1]-2,X.shape[1]-1, X.shape[1]]
 params={"objective":"huber","alpha":0.9,"learning_rate":0.05,"num_leaves":63,"min_data_in_leaf":50,"feature_fraction":0.9,"bagging_fraction":0.9,"bagging_freq":1,"max_bin":255,"num_threads":2,"verbosity":-1,"seed":1337}
 m_sorted=np.unique(month); m_sorted.sort()
 per=int(np.ceil(float(TREES)/float(m_sorted.size))) if m_sorted.size else TREES
 rem=int(TREES)
 booster=None
 pred=np.full(n,baseline_new,np.int16)
 rows=[]
 t0=time.perf_counter()
 for m in m_sorted.tolist():
  mm=(month==m)
  dec_idx=np.flatnonzero(mm & (keep==1))
  if booster is not None and dec_idx.size>0:
   Xmm=X[dec_idx]
   Q=np.empty((dec_idx.size,K),np.float32)
   for a in range(K):
    a_col=np.full((dec_idx.size,1),float(a),np.float32)
    Xa=np.concatenate([Xmm,a_col],axis=1)
    Q[:,a]=booster.predict(Xa,num_iteration=booster.current_iteration()).astype(np.float32)
   pred[dec_idx]=np.argmax(Q,axis=1).astype(np.int16)
  model_atr=acts[mm,pred[mm].astype(np.int64)]
  au=atr[mm]
  b_usd=float(np.sum(usd(base[mm],au)))
  o_usd=float(np.sum(usd(bestK[mm],au)))
  m_usd=float(np.sum(usd(model_atr,au)))
  rows.append({"month":int(m),"n":int(mm.sum()),"n_dec":int(dec_idx.size),"base_usd":b_usd,"model_usd":m_usd,"oracleK_usd":o_usd,"uplift_usd":m_usd-b_usd,"model_oracle_pct":(m_usd/o_usd if abs(o_usd)>1e-12 else 0.0)})
  tr_idx=np.flatnonzero(mm & (keep==1))
  if rem>0 and tr_idx.size>=NMIN_TRAIN:
   Xr=np.repeat(X[tr_idx],K,axis=0)
   a=np.tile(np.arange(K,dtype=np.int16),tr_idx.size).astype(np.float32).reshape(-1,1)
   y=acts[tr_idx].reshape(-1).astype(np.float32)
   base_rep=np.repeat(base[tr_idx],K).astype(np.float32)
   gain=(y-base_rep).astype(np.float32)
   wgt=np.clip(gain,0.0,2.0)+0.05
   Xa=np.concatenate([Xr,a],axis=1).astype(np.float32)
   dtrain=lgb.Dataset(Xa,label=y,weight=wgt,categorical_feature=cat_idx,free_raw_data=True)
   add=min(per,rem)
   booster=lgb.train(params,dtrain,num_boost_round=int(add),init_model=booster,keep_training_booster=True)
   rem-=int(add)
 rep=pd.DataFrame(rows)
 rep.to_csv(os.path.join(OUT_DIR,f"monthly_{stream}.csv"),index=False)
 used=int(TREES-rem)
 base_all=float(np.sum(usd(base,atr)))
 oracle_all=float(np.sum(usd(bestK,atr)))
 model_all=float(np.sum(usd(acts[np.arange(n),pred.astype(np.int64)],atr)))
 t1=time.perf_counter()
 if booster is not None:
  booster.save_model(os.path.join(OUT_DIR,f"qmodel_{stream}.txt"))
 return {"stream":stream,"n":int(n),"K":int(K),"trees_used":used,"train_sec":float(t1-t0),"base_usd":base_all,"model_usd":model_all,"oracleK_usd":oracle_all,"uplift_usd":model_all-base_all,"model_oracle_pct":(model_all/oracle_all if abs(oracle_all)>1e-12 else 0.0)}
def main():
 files=sorted([f for f in os.listdir(IN_DIR) if f.startswith("datasetK_") and f.endswith(".npz")])
 if not files: raise RuntimeError(("NO_DATASETK",IN_DIR))
 meta={"threads":2,"trees":TREES,"nmin_train":NMIN_TRAIN,"method":"Q(s,a) huber regression on long dataset (state,ctx,action)->pnl_atr","no_t":True}
 with open(os.path.join(OUT_DIR,"train_meta.json"),"w",encoding="utf-8") as f: json.dump(meta,f,ensure_ascii=False)
 print("ROOT",ROOT)
 print("IN_DIR",IN_DIR)
 print("OUT_DIR",OUT_DIR)
 print("THREADS",2,"TREES",TREES,"NMIN_TRAIN",NMIN_TRAIN,"METHOD","QVALUE_LONG")
 sums=[]
 for fn in files:
  stream=fn[len("datasetK_"):-4]
  z=np.load(os.path.join(IN_DIR,fn),allow_pickle=True)
  s=train_q_stream(stream,z)
  sums.append(s)
  print("STREAM",stream,"K",s["K"],"trees",s["trees_used"],"sec",fmt(s["train_sec"]),"BASE",fmt(s["base_usd"]),"MODEL",fmt(s["model_usd"]),"ORACLEK",fmt(s["oracleK_usd"]),"uplift",fmt(s["uplift_usd"]),"pct_oracle",fmt(s["model_oracle_pct"]))
 sumdf=pd.DataFrame(sums).sort_values("uplift_usd",ascending=False)
 sumdf.to_csv(os.path.join(OUT_DIR,"summary_streams.csv"),index=False)
 tot_base=float(sumdf["base_usd"].sum()); tot_model=float(sumdf["model_usd"].sum()); tot_or=float(sumdf["oracleK_usd"].sum())
 print("[12] SUMMARY_STREAMS")
 print(sumdf.to_string(index=False))
 print("[12] TOTAL","BASE",fmt(tot_base),"MODEL",fmt(tot_model),"ORACLEK",fmt(tot_or),"uplift",fmt(tot_model-tot_base),"pct_oracle",fmt((tot_model/tot_or if abs(tot_or)>1e-12 else 0.0)))
 print("[12] FILES summary_streams.csv monthly_*.csv qmodel_*.txt train_meta.json")
if __name__=="__main__":
 main()
