﻿import os,sys,json,time
import numpy as np,pandas as pd
import lightgbm as lgb
STREAMS=["222_high","222_mid","223_mid","332_high","332_mid","333_mid"]
BASELINE_OLD=10
TREES_CAP=1500
MIN_HIST_N=80
TAU=0.35
ADD_PER_MONTH=200
def _read_meta(m):
    try:
        if isinstance(m,np.ndarray) and m.size==1:
            s=m.reshape(-1)[0]
            if isinstance(s,bytes): s=s.decode("utf-8")
            return json.loads(str(s))
        if isinstance(m,(bytes,bytearray)): return json.loads(m.decode("utf-8"))
    except Exception:
        return {}
    return {}
def _renumber_cat_cols(Xc):
    Xc=np.array(Xc,copy=True)
    for j in range(Xc.shape[1]):
        col=Xc[:,j].astype(np.int64)
        uniq=np.unique(col)
        Xc[:,j]=np.searchsorted(uniq,col)
    return Xc.astype(np.int32)
def baseline_new_index(actions_old):
    w=np.where(actions_old==BASELINE_OLD)[0]
    return int(w[0]) if w.size else 0
def load_npz(path):
    d=np.load(path,allow_pickle=False)
    keys=set(d.files)
    need=["keep","pnl_atr_actions","actions_old","X","X_cat","y_e2","y_bestK"]
    miss=[k for k in need if k not in keys]
    if miss: raise RuntimeError(("NPZ_MISSING_KEYS",os.path.basename(path),miss,sorted(list(keys))))
    keep=d["keep"].astype(np.uint8).reshape(-1)
    X=d["X"].astype(np.float32)
    Xc=np.array(d["X_cat"],copy=False)
    if Xc.ndim==1: Xc=Xc.reshape(-1,1)
    if Xc.shape[0]!=X.shape[0]: raise RuntimeError(("NPZ_XCAT_ROWS_MISMATCH",os.path.basename(path),{"X":X.shape,"X_cat":Xc.shape}))
    Xc=Xc.astype(np.int32)
    meta=_read_meta(d["meta"]) if "meta" in keys else {}
    month_pos=int(meta.get("month_pos",Xc.shape[1]-1)) if isinstance(meta,dict) else (Xc.shape[1]-1)
    if month_pos<0 or month_pos>=Xc.shape[1]: month_pos=Xc.shape[1]-1
    month_raw=Xc[:,month_pos].astype(np.int32)
    Xc=_renumber_cat_cols(Xc)
    X_full=np.concatenate([X,Xc.astype(np.float32)],axis=1)
    cat_idx=np.arange(X.shape[1],X.shape[1]+Xc.shape[1],dtype=np.int32)
    y_e2=d["y_e2"].astype(np.int32).reshape(-1)
    y_bestK=d["y_bestK"].astype(np.int32).reshape(-1)
    pnl=d["pnl_atr_actions"].astype(np.float32)
    actions_old=d["actions_old"].astype(np.int32).reshape(-1)
    if keep.size!=X_full.shape[0] or keep.size!=y_e2.size or keep.size!=pnl.shape[0] or keep.size!=y_bestK.size:
        raise RuntimeError(("NPZ_SHAPE_MISMATCH",os.path.basename(path),{"keep":keep.shape,"X_full":X_full.shape,"y_e2":y_e2.shape,"y_bestK":y_bestK.shape,"pnl":pnl.shape}))
    if pnl.shape[1]!=actions_old.size:
        raise RuntimeError(("NPZ_ACTIONS_MISMATCH",os.path.basename(path),{"pnl_cols":int(pnl.shape[1]),"actions_old":int(actions_old.size)}))
    return keep,X_full,cat_idx,month_raw,y_e2,y_bestK,pnl,actions_old
def online_fw_gate(keep,X_full,cat_idx,month_raw,y_e2,y_bestK,pnl,actions_old,trees_cap,num_threads,min_hist_n,tau,add_per_month,params):
    bn=baseline_new_index(actions_old)
    use=(keep>0)
    months=np.unique(month_raw[use]);months=np.sort(months.astype(np.int32))
    trees_used=0
    booster=None
    base_sum=0.0
    model_sum=0.0
    switch_n=0
    dec_n=0
    for m in months:
        test_idx=np.where((month_raw==m)&use)[0]
        if test_idx.size==0: continue
        train_idx=np.where((month_raw<m)&use)[0]
        train_n=int(train_idx.size)
        if train_n>=int(min_hist_n) and trees_used<int(trees_cap):
            add=min(int(add_per_month),int(trees_cap-trees_used))
            dtrain=lgb.Dataset(X_full[train_idx],label=y_e2[train_idx],categorical_feature=cat_idx.tolist(),free_raw_data=True)
            if booster is None: booster=lgb.train(params,dtrain,num_boost_round=int(add))
            else: booster=lgb.train(params,dtrain,num_boost_round=int(add),init_model=booster,keep_training_booster=True)
            trees_used+=int(add)
        if booster is None:
            sw=np.zeros(test_idx.size,dtype=np.uint8)
        else:
            p=booster.predict(X_full[test_idx]).astype(np.float32)
            sw=(p>=float(tau)).astype(np.uint8)
        chosen=np.where(sw>0,y_bestK[test_idx],bn).astype(np.int32)
        base_m=float(pnl[test_idx,bn].sum())
        model_m=float(pnl[test_idx,chosen].sum())
        base_sum+=base_m;model_sum+=model_m;switch_n+=int(sw.sum());dec_n+=int(test_idx.size)
    uplift=float(model_sum-base_sum)
    avg_sw=float(switch_n/dec_n) if dec_n else 0.0
    return base_sum,model_sum,uplift,avg_sw,int(trees_used)
def main(root):
    IN_DIR=os.environ.get("IN_DIR",os.path.join(root,"LGBM","22","out"))
    OUT_DIR=os.environ.get("OUT_DIR",os.path.join(root,"LGBM","25","out"))
    THREADS=int(os.environ.get("THREADS","2"))
    MIN_LEAF_LIST=[int(x) for x in os.environ.get("MIN_LEAF_LIST","10,20,40,80,120").split(",")]
    LEAVES_LIST=[int(x) for x in os.environ.get("LEAVES_LIST","31,63,127").split(",")]
    os.makedirs(OUT_DIR,exist_ok=True)
    print("ROOT",root)
    print("IN_DIR",IN_DIR)
    print("OUT_DIR",OUT_DIR)
    print("THREADS",THREADS,"BASELINE_OLD",BASELINE_OLD)
    print("FIXED trees_cap",TREES_CAP,"min_hist_n",MIN_HIST_N,"tau",TAU,"add_per_month",ADD_PER_MONTH)
    print("MIN_LEAF_LIST",MIN_LEAF_LIST)
    print("LEAVES_LIST",LEAVES_LIST)
    datasets={}
    for s in STREAMS:
        p=os.path.join(IN_DIR,f"datasetE2_{s}.npz")
        datasets[s]=load_npz(p)
    rows=[];t0=time.time()
    for min_leaf in MIN_LEAF_LIST:
        for leaves in LEAVES_LIST:
            params={"objective":"binary","learning_rate":0.05,"num_leaves":int(leaves),"min_data_in_leaf":int(min_leaf),"feature_fraction":0.9,"bagging_fraction":0.9,"bagging_freq":1,"lambda_l2":1.0,"verbosity":-1,"num_threads":int(THREADS),"max_bin":255}
            tot_base=0.0;tot_model=0.0;tot_upl=0.0;sws=[];tus=[]
            for s in STREAMS:
                keep,X_full,cat_idx,month_raw,y_e2,y_bestK,pnl,actions_old=datasets[s]
                b,m,u,sw,tu=online_fw_gate(keep,X_full,cat_idx,month_raw,y_e2,y_bestK,pnl,actions_old,trees_cap=TREES_CAP,num_threads=THREADS,min_hist_n=MIN_HIST_N,tau=TAU,add_per_month=ADD_PER_MONTH,params=params)
                tot_base+=b;tot_model+=m;tot_upl+=u;sws.append(sw);tus.append(tu)
            avg_sw=float(np.mean(sws)) if sws else 0.0
            avg_tu=float(np.mean(tus)) if tus else 0.0
            rows.append([min_leaf,leaves,tot_base,tot_model,tot_upl,avg_sw,avg_tu])
            print("[GRID] min_leaf",min_leaf,"leaves",leaves,"UPLIFT_ATR",f"{tot_upl:.6f}","avg_sw",f"{avg_sw:.6f}","avg_trees_used",f"{avg_tu:.1f}")
    res=pd.DataFrame(rows,columns=["min_data_in_leaf","num_leaves","base_atr_sum","model_atr_sum","uplift_atr_sum","avg_switch_rate","avg_trees_used"])
    res=res.sort_values(["uplift_atr_sum","avg_switch_rate"],ascending=[False,True]).reset_index(drop=True)
    res.to_csv(os.path.join(OUT_DIR,"grid_leaf.csv"),index=False)
    print("[25] TOP10")
    print(res.head(10).to_string(index=False))
    best=res.iloc[0].to_dict() if len(res) else {}
    meta={"fixed":{"trees_cap":TREES_CAP,"min_hist_n":MIN_HIST_N,"tau":TAU,"add_per_month":ADD_PER_MONTH},"best":best,"n_rows":int(len(res)),"elapsed_sec":float(time.time()-t0)}
    with open(os.path.join(OUT_DIR,"best_config.json"),"w",encoding="utf-8") as f: json.dump(meta,f,ensure_ascii=False,indent=2)
    print("[25] FILES grid_leaf.csv best_config.json")
if __name__=="__main__":
    root=sys.argv[1] if len(sys.argv)>1 else os.getcwd()
    main(root)
